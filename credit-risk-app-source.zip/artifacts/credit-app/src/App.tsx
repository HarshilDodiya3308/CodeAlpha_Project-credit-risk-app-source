import { Switch, Route, Router as WouterRouter, Redirect } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { setAuthTokenGetter } from "@workspace/api-client-react";
import { useAuth } from "@/hooks/use-auth";

import NotFound from "@/pages/not-found";
import { Layout } from "@/components/layout";

// Pages (to be implemented)
import Login from "@/pages/login";
import Register from "@/pages/register";
import Dashboard from "@/pages/dashboard";
import Predict from "@/pages/predict";
import Predictions from "@/pages/predictions";
import PredictionDetail from "@/pages/prediction-detail";
import Models from "@/pages/models";

setAuthTokenGetter(() => localStorage.getItem("token"));

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 1,
      refetchOnWindowFocus: false,
    },
  },
});

function ProtectedRoute({ component: Component, ...rest }: any) {
  const { token } = useAuth();
  if (!token) {
    return <Redirect to="/login" />;
  }
  return (
    <Layout>
      <Component {...rest} />
    </Layout>
  );
}

function Router() {
  const { token } = useAuth();

  return (
    <Switch>
      <Route path="/">
        {token ? <Redirect to="/dashboard" /> : <Redirect to="/login" />}
      </Route>
      <Route path="/login" component={Login} />
      <Route path="/register" component={Register} />

      <Route path="/dashboard">
        {() => <ProtectedRoute component={Dashboard} />}
      </Route>
      <Route path="/predict">
        {() => <ProtectedRoute component={Predict} />}
      </Route>
      <Route path="/predictions">
        {() => <ProtectedRoute component={Predictions} />}
      </Route>
      <Route path="/predictions/:id">
        {(params) => <ProtectedRoute component={PredictionDetail} params={params} />}
      </Route>
      <Route path="/models">
        {() => <ProtectedRoute component={Models} />}
      </Route>

      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
