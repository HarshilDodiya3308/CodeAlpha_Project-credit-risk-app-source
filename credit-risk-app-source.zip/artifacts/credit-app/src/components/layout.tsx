import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { LayoutDashboard, Calculator, History, Cpu, LogOut, ChevronRight } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

interface LayoutProps {
  children: React.ReactNode;
}

export function Layout({ children }: LayoutProps) {
  const [location] = useLocation();
  const { user, logout } = useAuth();

  const navItems = [
    { label: "Dashboard", href: "/dashboard", icon: LayoutDashboard, color: "#60a5fa" },
    { label: "Predict Risk", href: "/predict", icon: Calculator, color: "#a78bfa" },
    { label: "History", href: "/predictions", icon: History, color: "#34d399" },
    { label: "ML Models", href: "/models", icon: Cpu, color: "#f59e0b" },
  ];

  const initials = user?.username
    ? user.username.slice(0, 2).toUpperCase()
    : "??";

  return (
    <div className="flex h-screen w-full overflow-hidden text-foreground"
      style={{ background: "linear-gradient(135deg, #030712 0%, #0d1120 100%)" }}>
      
      <aside className="w-64 flex flex-col shrink-0 hidden md:flex relative"
        style={{
          background: "rgba(5, 10, 24, 0.95)",
          borderRight: "1px solid rgba(255,255,255,0.06)",
          backdropFilter: "blur(20px)",
        }}>
        
        <div className="absolute inset-0 pointer-events-none overflow-hidden rounded-r-none">
          <div className="absolute top-0 left-0 right-0 h-px"
            style={{ background: "linear-gradient(90deg, transparent, rgba(99,130,246,0.3), transparent)" }} />
        </div>

        <div className="h-16 flex items-center px-5"
          style={{ borderBottom: "1px solid rgba(255,255,255,0.05)" }}>
          <div className="flex items-center gap-2.5">
            <div className="h-8 w-8 rounded-lg flex items-center justify-center flex-shrink-0"
              style={{ background: "linear-gradient(135deg, #3b82f6, #8b5cf6)" }}>
              <span className="text-white font-bold text-xs">CR</span>
            </div>
            <div>
              <div className="font-mono font-bold text-sm tracking-tight gradient-text-blue">CREDIT_RISK</div>
              <div className="text-[9px] text-muted-foreground uppercase tracking-widest">OS v2.0</div>
            </div>
          </div>
        </div>

        <nav className="flex-1 py-5 px-3 space-y-1">
          <p className="text-[10px] text-muted-foreground uppercase tracking-widest font-semibold px-2 mb-3">Navigation</p>
          {navItems.map((item) => {
            const isActive = location === item.href || location.startsWith(item.href + "/");
            return (
              <Link key={item.href} href={item.href}>
                <div className="relative cursor-pointer group">
                  <AnimatePresence>
                    {isActive && (
                      <motion.div
                        layoutId="nav-active"
                        className="absolute inset-0 rounded-lg"
                        style={{
                          background: `linear-gradient(135deg, ${item.color}18, ${item.color}08)`,
                          border: `1px solid ${item.color}25`,
                        }}
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        transition={{ duration: 0.2 }}
                      />
                    )}
                  </AnimatePresence>
                  <div className={`relative flex items-center justify-between px-3 py-2.5 rounded-lg text-sm font-medium transition-all ${
                    isActive ? "" : "hover:bg-white/5"
                  }`}>
                    <div className="flex items-center gap-3">
                      <div className="h-7 w-7 rounded-md flex items-center justify-center transition-all"
                        style={{
                          background: isActive ? `${item.color}20` : "rgba(255,255,255,0.04)",
                          boxShadow: isActive ? `0 0 12px ${item.color}30` : "none",
                        }}>
                        <item.icon className="h-3.5 w-3.5 transition-all"
                          style={{ color: isActive ? item.color : "rgba(255,255,255,0.4)" }} />
                      </div>
                      <span style={{ color: isActive ? "white" : "rgba(255,255,255,0.5)" }}
                        className="transition-colors group-hover:text-white">
                        {item.label}
                      </span>
                    </div>
                    {isActive && (
                      <ChevronRight className="h-3.5 w-3.5 opacity-50" style={{ color: item.color }} />
                    )}
                  </div>
                </div>
              </Link>
            );
          })}
        </nav>

        <div className="p-3" style={{ borderTop: "1px solid rgba(255,255,255,0.05)" }}>
          <div className="flex items-center gap-3 p-2.5 rounded-lg mb-2"
            style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.05)" }}>
            <div className="h-8 w-8 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0"
              style={{ background: "linear-gradient(135deg, #3b82f6, #8b5cf6)" }}>
              {initials}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium truncate">{user?.username || "Agent"}</p>
              <p className="text-[10px] text-muted-foreground truncate">{user?.email || ""}</p>
            </div>
          </div>
          <button
            className="w-full flex items-center gap-2 px-3 py-2 rounded-lg text-sm text-muted-foreground transition-all hover:bg-white/5 hover:text-destructive"
            onClick={() => logout()}
          >
            <LogOut className="h-4 w-4" />
            Sign Out
          </button>
        </div>
      </aside>

      <main className="flex-1 flex flex-col min-w-0 overflow-auto">
        <AnimatePresence mode="wait">
          <motion.div
            key={location}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.25, ease: "easeOut" }}
            className="h-full w-full"
          >
            {children}
          </motion.div>
        </AnimatePresence>
      </main>
    </div>
  );
}
