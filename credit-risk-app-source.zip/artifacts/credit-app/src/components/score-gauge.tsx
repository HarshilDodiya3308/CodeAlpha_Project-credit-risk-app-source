import { useEffect, useRef } from "react";

interface ScoreGaugeProps {
  score: number;
  size?: number;
  animate?: boolean;
}

function getColor(score: number) {
  if (score >= 70) return { stroke: "#10b981", glow: "rgba(16,185,129,0.4)", label: "LOW RISK" };
  if (score >= 50) return { stroke: "#f59e0b", glow: "rgba(245,158,11,0.4)", label: "MEDIUM RISK" };
  return { stroke: "#f43f5e", glow: "rgba(244,63,94,0.4)", label: "HIGH RISK" };
}

export function ScoreGauge({ score, size = 220, animate = true }: ScoreGaugeProps) {
  const circleRef = useRef<SVGCircleElement>(null);
  const clampedScore = Math.max(0, Math.min(100, score));
  const { stroke, glow, label } = getColor(clampedScore);

  const cx = size / 2;
  const cy = size / 2;
  const r = size * 0.38;
  const strokeW = size * 0.065;

  const totalArc = 260;
  const startAngle = 140;
  const circumference = 2 * Math.PI * r;
  const arcFraction = totalArc / 360;
  const arcLen = circumference * arcFraction;
  const fillLen = (clampedScore / 100) * arcLen;

  useEffect(() => {
    const el = circleRef.current;
    if (!el || !animate) return;
    el.style.strokeDasharray = `${arcLen} ${circumference}`;
    el.style.strokeDashoffset = `${arcLen}`;
    el.style.transition = "none";
    requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        el.style.transition = "stroke-dashoffset 1.6s cubic-bezier(0.34, 1.56, 0.64, 1)";
        el.style.strokeDashoffset = `${arcLen - fillLen}`;
      });
    });
  }, [score, arcLen, circumference, fillLen, animate]);

  const toXY = (angleDeg: number) => {
    const rad = ((angleDeg - 90) * Math.PI) / 180;
    return { x: cx + r * Math.cos(rad), y: cy + r * Math.sin(rad) };
  };

  const start = toXY(startAngle);
  const end = toXY(startAngle + totalArc);
  const trackPath = `M ${start.x} ${start.y} A ${r} ${r} 0 1 1 ${end.x} ${end.y}`;

  return (
    <div className="relative flex flex-col items-center">
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} className="drop-shadow-lg">
        <defs>
          <filter id="gauge-glow">
            <feGaussianBlur stdDeviation="4" result="coloredBlur" />
            <feMerge>
              <feMergeNode in="coloredBlur" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
          <filter id="glow-soft">
            <feGaussianBlur stdDeviation="8" result="blur" />
            <feMerge>
              <feMergeNode in="blur" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
        </defs>

        <path
          d={trackPath}
          fill="none"
          stroke="rgba(255,255,255,0.07)"
          strokeWidth={strokeW}
          strokeLinecap="round"
        />

        <circle
          ref={circleRef}
          cx={cx}
          cy={cy}
          r={r}
          fill="none"
          stroke={stroke}
          strokeWidth={strokeW}
          strokeLinecap="round"
          transform={`rotate(${startAngle} ${cx} ${cy})`}
          style={{
            filter: `drop-shadow(0 0 8px ${glow})`,
          }}
        />

        <text
          x={cx}
          y={cy - 8}
          textAnchor="middle"
          dominantBaseline="middle"
          fontSize={size * 0.2}
          fontWeight="700"
          fontFamily="monospace"
          fill="white"
        >
          {clampedScore.toFixed(0)}
        </text>
        <text
          x={cx}
          y={cy + size * 0.13}
          textAnchor="middle"
          dominantBaseline="middle"
          fontSize={size * 0.07}
          fontWeight="500"
          fill={stroke}
          fontFamily="monospace"
          letterSpacing="2"
        >
          {label}
        </text>

        <text x={cx - r + 4} y={cy + r * 0.5 + 4} textAnchor="middle" fontSize={size * 0.065} fill="rgba(255,255,255,0.3)" fontFamily="monospace">0</text>
        <text x={cx + r - 4} y={cy + r * 0.5 + 4} textAnchor="middle" fontSize={size * 0.065} fill="rgba(255,255,255,0.3)" fontFamily="monospace">100</text>
      </svg>
    </div>
  );
}
