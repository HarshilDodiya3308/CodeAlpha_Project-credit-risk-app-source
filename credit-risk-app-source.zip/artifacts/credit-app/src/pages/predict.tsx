import { useState, useEffect, useMemo } from "react";
import { useCreatePrediction } from "@workspace/api-client-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Badge } from "@/components/ui/badge";
import { ScoreGauge } from "@/components/score-gauge";
import { motion, AnimatePresence } from "framer-motion";
import { Loader2, ArrowRight, Brain, Lightbulb, TrendingUp, AlertTriangle, CheckCircle } from "lucide-react";
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis, Cell, ReferenceLine } from "recharts";
import { toast } from "sonner";

const predictionSchema = z.object({
  age: z.number().min(18).max(100),
  income: z.coerce.number().min(0),
  employmentLength: z.coerce.number().min(0),
  creditHistory: z.coerce.number().min(0),
  existingDebt: z.coerce.number().min(0),
  loanAmount: z.coerce.number().min(1),
  loanPurpose: z.enum(["personal", "business", "education", "medical", "home", "auto", "other"]),
  modelName: z.enum(["logistic_regression", "decision_tree", "random_forest", "xgboost"]),
});

type PredictionForm = z.infer<typeof predictionSchema>;

function estimateLiveScore(values: Partial<PredictionForm>): number {
  const income = Number(values.income) || 0;
  const creditHistory = Number(values.creditHistory) || 0;
  const employment = Number(values.employmentLength) || 0;
  const debt = Number(values.existingDebt) || 0;
  const loan = Number(values.loanAmount) || 1;
  const age = Number(values.age) || 30;

  let score = 50;
  score += Math.min((income / 120000) * 20, 20);
  score += Math.min((creditHistory / 120) * 15, 15);
  score += Math.min((employment / 12) * 10, 10);
  score -= Math.min((debt / Math.max(income, 1)) * 20, 20);
  score -= Math.min((loan / Math.max(income, 1)) * 15, 15);
  score += age > 30 ? 5 : age > 25 ? 2 : 0;
  const purposeBonus: Record<string, number> = { home: 4, education: 3, business: 2, auto: 2, medical: 1, personal: 0, other: -1 };
  score += purposeBonus[values.loanPurpose || "personal"] || 0;
  return Math.max(5, Math.min(95, score));
}

function getRiskColor(score: number) {
  if (score >= 70) return { color: "#10b981", label: "Low Risk", bg: "rgba(16,185,129,0.1)", border: "rgba(16,185,129,0.25)" };
  if (score >= 50) return { color: "#f59e0b", label: "Medium Risk", bg: "rgba(245,158,11,0.1)", border: "rgba(245,158,11,0.25)" };
  return { color: "#f43f5e", label: "High Risk", bg: "rgba(244,63,94,0.1)", border: "rgba(244,63,94,0.25)" };
}

function getRecommendations(result: any, formValues: PredictionForm): string[] {
  const tips: string[] = [];
  const income = Number(formValues.income);
  const debt = Number(formValues.existingDebt);
  const creditHistory = Number(formValues.creditHistory);
  const loan = Number(formValues.loanAmount);
  const employment = Number(formValues.employmentLength);

  if (!result.creditworthy) {
    if (debt / income > 0.3) tips.push(`Reduce existing debt below ${(income * 0.3).toLocaleString('en', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 })} (currently ${(debt / income * 100).toFixed(0)}% of income).`);
    if (creditHistory < 36) tips.push("Build credit history to at least 36 months before reapplying.");
    if (loan > income * 0.5) tips.push(`Consider a smaller loan — requested amount is ${(loan / income * 100).toFixed(0)}% of your annual income.`);
    if (employment < 2) tips.push("Maintain stable employment for at least 2 years to improve your profile.");
    if (income < 40000) tips.push("A higher income or co-applicant would significantly improve approval odds.");
    if (tips.length === 0) tips.push("Address your debt-to-income ratio and ensure credit history is accurate.");
  } else {
    tips.push("Strong profile! Consider comparing rates with multiple lenders to get the best terms.");
    if (result.creditScore < 80) tips.push("Paying down existing debt could push your score into the excellent tier.");
    if (result.creditScore >= 80) tips.push("Excellent score — you qualify for premium interest rates.");
  }
  return tips.slice(0, 3);
}

const MODEL_INFO: Record<string, { name: string; speed: string; accuracy: string; desc: string }> = {
  random_forest: { name: "Random Forest", speed: "Fast", accuracy: "75.1%", desc: "Ensemble of decision trees, great balance" },
  xgboost: { name: "XGBoost", speed: "Fast", accuracy: "78.2%", desc: "Best accuracy, industry standard" },
  logistic_regression: { name: "Logistic Regression", speed: "Fastest", accuracy: "75.6%", desc: "Highly interpretable baseline" },
  decision_tree: { name: "Decision Tree", speed: "Fastest", accuracy: "73.8%", desc: "Fully explainable single tree" },
};

export default function Predict() {
  const createPrediction = useCreatePrediction();
  const [result, setResult] = useState<any>(null);

  const form = useForm<PredictionForm>({
    resolver: zodResolver(predictionSchema),
    defaultValues: {
      age: 35,
      income: 60000,
      employmentLength: 5,
      creditHistory: 72,
      existingDebt: 15000,
      loanAmount: 20000,
      loanPurpose: "personal",
      modelName: "xgboost",
    },
  });

  const watchedValues = form.watch();
  const liveScore = useMemo(() => estimateLiveScore(watchedValues), [
    watchedValues.age, watchedValues.income, watchedValues.employmentLength,
    watchedValues.creditHistory, watchedValues.existingDebt, watchedValues.loanAmount,
    watchedValues.loanPurpose,
  ]);
  const liveRisk = getRiskColor(liveScore);

  const onSubmit = (data: PredictionForm) => {
    setResult(null);
    createPrediction.mutate(
      { data },
      {
        onSuccess: (res) => {
          setResult(res);
          toast.success("Assessment complete");
        },
        onError: (err: any) => {
          toast.error(err?.message || "Failed to run prediction");
        },
      }
    );
  };

  const shapData = result?.shapValues
    ? [...result.shapValues].sort((a: any, b: any) => Math.abs(b.impact) - Math.abs(a.impact)).slice(0, 8)
    : [];

  const selectedModel = MODEL_INFO[watchedValues.modelName] || MODEL_INFO.xgboost;
  const recommendations = result ? getRecommendations(result, watchedValues) : [];

  return (
    <div className="p-6 max-w-[1600px] mx-auto">
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-6"
      >
        <h1 className="text-3xl font-bold tracking-tight gradient-text">Predict Risk</h1>
        <p className="text-muted-foreground text-sm mt-1">Run a credit assessment using deployed ML models with SHAP explainability.</p>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.1 }}
          className="lg:col-span-5"
        >
          <div className="glass-light rounded-xl border border-white/5 overflow-hidden">
            <div className="p-5 border-b border-white/5">
              <div className="flex items-center gap-2 mb-1">
                <Brain className="h-4 w-4 text-primary" />
                <h2 className="font-semibold text-sm">Applicant Profile</h2>
              </div>
              <p className="text-xs text-muted-foreground">Input financial parameters for scoring.</p>
            </div>

            <div className="p-5 border-b border-white/5">
              <div className="flex items-center justify-between mb-1">
                <p className="text-xs text-muted-foreground font-semibold uppercase tracking-wider">Live Estimate</p>
                <span className="text-[10px] px-2 py-0.5 rounded-full font-mono"
                  style={{ background: liveRisk.bg, color: liveRisk.color, border: `1px solid ${liveRisk.border}` }}>
                  {liveRisk.label}
                </span>
              </div>
              <div className="flex items-end gap-3 mt-2">
                <div className="h-1.5 flex-1 rounded-full overflow-hidden" style={{ background: "rgba(255,255,255,0.07)" }}>
                  <motion.div
                    className="h-full rounded-full transition-all duration-700"
                    style={{ width: `${liveScore}%`, background: `linear-gradient(90deg, #f43f5e, ${liveScore > 50 ? "#f59e0b" : "#f43f5e"}, ${liveScore > 70 ? "#10b981" : "transparent"})` }}
                  />
                </div>
                <span className="text-2xl font-bold font-mono w-12 text-right" style={{ color: liveRisk.color }}>
                  {liveScore.toFixed(0)}
                </span>
              </div>
            </div>

            <form id="prediction-form" onSubmit={form.handleSubmit(onSubmit)} className="p-5 space-y-5">
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <Label className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Age</Label>
                  <span className="text-sm font-mono font-semibold text-primary">{form.watch("age")} yrs</span>
                </div>
                <Slider min={18} max={80} step={1} value={[form.watch("age")]}
                  onValueChange={(val) => form.setValue("age", val[0])}
                  className="[&>span]:bg-primary" />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Annual Income</Label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground text-sm">$</span>
                    <Input type="number" className="pl-7 bg-white/5 border-white/10 focus:border-primary/50 h-10 text-sm"
                      {...form.register("income")} />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Employment (Yrs)</Label>
                  <Input type="number" className="bg-white/5 border-white/10 focus:border-primary/50 h-10 text-sm"
                    {...form.register("employmentLength")} />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Existing Debt</Label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground text-sm">$</span>
                    <Input type="number" className="pl-7 bg-white/5 border-white/10 focus:border-primary/50 h-10 text-sm"
                      {...form.register("existingDebt")} />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Credit Hist (Mo)</Label>
                  <Input type="number" className="bg-white/5 border-white/10 focus:border-primary/50 h-10 text-sm"
                    {...form.register("creditHistory")} />
                </div>
              </div>

              <div className="space-y-2">
                <Label className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Loan Amount</Label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground text-sm">$</span>
                  <Input type="number" className="pl-7 bg-white/5 border-white/10 focus:border-primary/50 h-10 text-sm"
                    {...form.register("loanAmount")} />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Purpose</Label>
                  <Select onValueChange={(val: any) => form.setValue("loanPurpose", val)} defaultValue={form.getValues("loanPurpose")}>
                    <SelectTrigger className="bg-white/5 border-white/10 h-10 text-sm">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {["personal","business","education","medical","home","auto","other"].map(v => (
                        <SelectItem key={v} value={v} className="capitalize">{v.charAt(0).toUpperCase() + v.slice(1)}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Model</Label>
                  <Select onValueChange={(val: any) => form.setValue("modelName", val)} defaultValue={form.getValues("modelName")}>
                    <SelectTrigger className="bg-white/5 border-white/10 h-10 text-sm">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {Object.entries(MODEL_INFO).map(([key, m]) => (
                        <SelectItem key={key} value={key}>{m.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="rounded-lg p-3 text-xs space-y-1" style={{ background: "rgba(99,130,246,0.08)", border: "1px solid rgba(99,130,246,0.15)" }}>
                <div className="flex items-center gap-1.5 text-primary font-semibold">
                  <Brain className="h-3.5 w-3.5" />
                  {selectedModel.name}
                </div>
                <p className="text-muted-foreground">{selectedModel.desc}</p>
                <div className="flex gap-3 pt-0.5">
                  <span className="text-muted-foreground">Speed: <span className="text-foreground">{selectedModel.speed}</span></span>
                  <span className="text-muted-foreground">CV Accuracy: <span className="text-foreground">{selectedModel.accuracy}</span></span>
                </div>
              </div>
            </form>

            <div className="px-5 pb-5">
              <Button type="submit" form="prediction-form" className="w-full h-11 font-semibold"
                disabled={createPrediction.isPending}
                style={{ background: createPrediction.isPending ? undefined : "linear-gradient(135deg, #3b82f6, #8b5cf6)" }}>
                {createPrediction.isPending ? (
                  <span className="flex items-center gap-2">
                    <Loader2 className="h-4 w-4 animate-spin" />
                    Running Assessment...
                  </span>
                ) : (
                  <span className="flex items-center gap-2">
                    Run Assessment <ArrowRight className="h-4 w-4" />
                  </span>
                )}
              </Button>
            </div>
          </div>
        </motion.div>

        <div className="lg:col-span-7 space-y-5">
          <AnimatePresence mode="wait">
            {result ? (
              <motion.div
                key="result"
                initial={{ opacity: 0, scale: 0.97, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.97 }}
                transition={{ duration: 0.5, ease: "easeOut" }}
                className="space-y-5"
              >
                <div className="rounded-xl p-6 relative overflow-hidden"
                  style={{
                    background: result.creditworthy
                      ? "linear-gradient(135deg, rgba(16,185,129,0.08), rgba(16,185,129,0.04))"
                      : "linear-gradient(135deg, rgba(244,63,94,0.08), rgba(244,63,94,0.04))",
                    border: `1px solid ${result.creditworthy ? "rgba(16,185,129,0.2)" : "rgba(244,63,94,0.2)"}`,
                    boxShadow: result.creditworthy
                      ? "0 0 40px rgba(16,185,129,0.1)"
                      : "0 0 40px rgba(244,63,94,0.1)",
                  }}>
                  <div className="absolute top-0 right-0 w-48 h-48 rounded-full blur-3xl opacity-10 pointer-events-none"
                    style={{ background: result.creditworthy ? "#10b981" : "#f43f5e", transform: "translate(30%, -30%)" }} />

                  <div className="flex flex-col md:flex-row items-center gap-6">
                    <div className="flex-shrink-0">
                      <ScoreGauge score={result.creditScore} size={200} animate />
                    </div>
                    <div className="flex-1 text-center md:text-left">
                      <p className="text-xs font-semibold uppercase tracking-widest text-muted-foreground mb-2">Assessment Verdict</p>
                      <div className="text-5xl font-black tracking-tight mb-3 flex items-center gap-3 justify-center md:justify-start"
                        style={{ color: result.creditworthy ? "#10b981" : "#f43f5e" }}>
                        {result.creditworthy ? <CheckCircle className="h-10 w-10" /> : <AlertTriangle className="h-10 w-10" />}
                        {result.creditworthy ? "APPROVED" : "REJECTED"}
                      </div>
                      <div className="flex items-center gap-2 flex-wrap justify-center md:justify-start">
                        <span className="text-xs px-2 py-1 rounded-full font-mono"
                          style={{ background: "rgba(255,255,255,0.07)", border: "1px solid rgba(255,255,255,0.1)" }}>
                          {result.modelUsed?.replace(/_/g, " ").toUpperCase()}
                        </span>
                        <span className="text-xs px-2 py-1 rounded-full font-mono font-semibold"
                          style={{
                            background: result.riskLevel === 'low' ? "rgba(16,185,129,0.15)" : result.riskLevel === 'medium' ? "rgba(245,158,11,0.15)" : "rgba(244,63,94,0.15)",
                            color: result.riskLevel === 'low' ? "#10b981" : result.riskLevel === 'medium' ? "#f59e0b" : "#f43f5e",
                          }}>
                          {result.riskLevel.toUpperCase()} RISK
                        </span>
                        <span className="text-xs px-2 py-1 rounded-full font-mono"
                          style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.08)" }}>
                          {(result.probability * 100).toFixed(1)}% probability
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                {recommendations.length > 0 && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.3 }}
                    className="rounded-xl p-4 space-y-3"
                    style={{ background: "rgba(245,158,11,0.06)", border: "1px solid rgba(245,158,11,0.15)" }}
                  >
                    <div className="flex items-center gap-2 text-amber-400 font-semibold text-sm">
                      <Lightbulb className="h-4 w-4" />
                      {result.creditworthy ? "Optimization Tips" : "Improvement Recommendations"}
                    </div>
                    <ul className="space-y-2">
                      {recommendations.map((tip, i) => (
                        <motion.li
                          key={i}
                          initial={{ opacity: 0, x: -10 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: 0.35 + i * 0.08 }}
                          className="flex items-start gap-2 text-xs text-muted-foreground"
                        >
                          <TrendingUp className="h-3.5 w-3.5 text-amber-400 mt-0.5 flex-shrink-0" />
                          {tip}
                        </motion.li>
                      ))}
                    </ul>
                  </motion.div>
                )}

                {shapData.length > 0 && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.4 }}
                    className="glass-light rounded-xl border border-white/5 overflow-hidden"
                  >
                    <div className="p-4 border-b border-white/5">
                      <h3 className="font-semibold text-sm">Feature Impact Analysis</h3>
                      <p className="text-xs text-muted-foreground mt-0.5">
                        SHAP values — how each input drove this decision. <span className="text-emerald-400">Green = positive</span>, <span className="text-rose-400">red = negative</span>.
                      </p>
                    </div>
                    <div className="p-4 h-[320px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={shapData} layout="vertical" margin={{ top: 0, right: 30, left: 80, bottom: 0 }}>
                          <CartesianGrid strokeDasharray="3 3" horizontal={false} vertical={true} stroke="rgba(255,255,255,0.05)" />
                          <XAxis type="number" stroke="rgba(255,255,255,0.2)" fontSize={11} tickLine={false} axisLine={false} tickFormatter={(v) => v.toFixed(3)} />
                          <YAxis type="category" dataKey="feature" stroke="rgba(255,255,255,0.2)" fontSize={11} tickLine={false} axisLine={false} />
                          <ReferenceLine x={0} stroke="rgba(255,255,255,0.2)" strokeWidth={1} />
                          <Tooltip
                            cursor={{ fill: "rgba(255,255,255,0.04)" }}
                            contentStyle={{ backgroundColor: 'rgba(15,23,42,0.95)', borderColor: 'rgba(255,255,255,0.1)', borderRadius: '10px', fontSize: '12px' }}
                            formatter={(val: number) => [val.toFixed(4), "SHAP Impact"]}
                          />
                          <Bar dataKey="impact" barSize={20} radius={[0, 5, 5, 0]}>
                            {shapData.map((entry: any, index: number) => (
                              <Cell key={`cell-${index}`}
                                fill={entry.impact > 0 ? "#10b981" : "#f43f5e"}
                                style={{ filter: `drop-shadow(0 0 4px ${entry.impact > 0 ? "rgba(16,185,129,0.4)" : "rgba(244,63,94,0.4)"})` }}
                              />
                            ))}
                          </Bar>
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </motion.div>
                )}
              </motion.div>
            ) : (
              <motion.div
                key="placeholder"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="h-full min-h-[500px] flex flex-col items-center justify-center rounded-xl text-center p-8"
                style={{ border: "1px dashed rgba(255,255,255,0.08)", background: "rgba(255,255,255,0.02)" }}
              >
                <div className="relative mb-6">
                  <div className="h-20 w-20 rounded-2xl flex items-center justify-center animate-pulse"
                    style={{ background: "rgba(59,130,246,0.1)", border: "1px solid rgba(59,130,246,0.2)" }}>
                    <Brain className="h-10 w-10 text-primary opacity-60" />
                  </div>
                  <div className="absolute -top-1 -right-1 h-4 w-4 rounded-full bg-primary/40 animate-ping" />
                </div>
                <p className="text-muted-foreground text-sm mb-1">AI engine ready</p>
                <p className="text-xs text-muted-foreground/60">Adjust parameters on the left and click <strong className="text-primary">Run Assessment</strong></p>
                <div className="mt-6 flex items-center gap-2 text-xs text-muted-foreground/50">
                  <span className="flex items-center gap-1.5">
                    <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse" />
                    Live estimate updating as you type
                  </span>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}
