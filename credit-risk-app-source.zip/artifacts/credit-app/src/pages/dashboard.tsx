import {
  useGetDashboardStats,
  useGetRiskDistribution,
  useGetFeatureImportance,
  useGetPredictions
} from "@workspace/api-client-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis,
  Area, AreaChart, Pie, PieChart, Cell
} from "recharts";
import { Activity, TrendingUp, ShieldAlert, CheckCircle2, Clock } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { useLocation } from "wouter";
import { format } from "date-fns";
import { AnimatedCounter } from "@/components/animated-counter";
import { motion } from "framer-motion";

const RISK_COLORS = {
  high: "#f43f5e",
  medium: "#f59e0b",
  low: "#10b981",
};

const statCards = (stats: any) => [
  {
    label: "Total Assessments",
    value: stats.totalPredictions,
    sub: `+${stats.todayPredictions} today`,
    icon: Activity,
    color: "#60a5fa",
    glow: "rgba(96,165,250,0.2)",
    decimals: 0,
    suffix: "",
  },
  {
    label: "Approval Rate",
    value: stats.approvalRate * 100,
    sub: "of all applicants",
    icon: CheckCircle2,
    color: "#10b981",
    glow: "rgba(16,185,129,0.2)",
    decimals: 1,
    suffix: "%",
  },
  {
    label: "Avg Credit Score",
    value: stats.avgCreditScore,
    sub: "portfolio average",
    icon: TrendingUp,
    color: "#a78bfa",
    glow: "rgba(167,139,250,0.2)",
    decimals: 1,
    suffix: "",
  },
  {
    label: "High Risk Density",
    value: (stats.highRiskCount / (stats.totalPredictions || 1)) * 100,
    sub: `${stats.highRiskCount} flagged`,
    icon: ShieldAlert,
    color: "#f43f5e",
    glow: "rgba(244,63,94,0.2)",
    decimals: 1,
    suffix: "%",
  },
];

const containerVariants = {
  hidden: {},
  visible: { transition: { staggerChildren: 0.08 } },
};
const cardVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.4, ease: "easeOut" } },
};

export default function Dashboard() {
  const [, setLocation] = useLocation();
  const { data: stats, isLoading: statsLoading } = useGetDashboardStats();
  const { data: riskDist, isLoading: riskLoading } = useGetRiskDistribution();
  const { data: featureImp, isLoading: featureLoading } = useGetFeatureImportance();
  const { data: recent, isLoading: recentLoading } = useGetPredictions({ limit: 5 });

  const pieData = stats
    ? [
        { name: "High Risk", value: stats.highRiskCount, color: RISK_COLORS.high },
        { name: "Medium Risk", value: stats.mediumRiskCount, color: RISK_COLORS.medium },
        { name: "Low Risk", value: stats.lowRiskCount, color: RISK_COLORS.low },
      ]
    : [];

  return (
    <div className="p-6 space-y-6 max-w-[1600px] mx-auto">
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="flex flex-col md:flex-row md:items-center justify-between gap-4"
      >
        <div>
          <h1 className="text-3xl font-bold tracking-tight gradient-text">Overview</h1>
          <p className="text-muted-foreground text-sm mt-1">Portfolio credit risk intelligence at a glance.</p>
        </div>
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <span className="inline-flex items-center gap-1.5">
            <span className="h-2 w-2 rounded-full bg-emerald-400 animate-pulse" />
            Models online
          </span>
          <span className="text-muted-foreground/40">•</span>
          <Clock className="h-3 w-3" />
          <span>Live</span>
        </div>
      </motion.div>

      {statsLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {[...Array(4)].map((_, i) => (
            <Skeleton key={i} className="h-32 w-full rounded-xl" />
          ))}
        </div>
      ) : stats ? (
        <motion.div
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4"
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
          {statCards(stats).map((card) => {
            const Icon = card.icon;
            return (
              <motion.div key={card.label} variants={cardVariants}>
                <div
                  className="relative rounded-xl p-5 overflow-hidden card-hover cursor-default"
                  style={{
                    background: `linear-gradient(135deg, rgba(15,23,42,0.9), rgba(15,23,42,0.7))`,
                    border: `1px solid ${card.color}20`,
                    boxShadow: `0 0 24px ${card.glow}, inset 0 1px 0 rgba(255,255,255,0.05)`,
                  }}
                >
                  <div className="absolute top-0 right-0 w-24 h-24 rounded-full blur-2xl opacity-20 pointer-events-none"
                    style={{ background: card.color, transform: "translate(30%, -30%)" }} />
                  <div className="flex items-center justify-between mb-3">
                    <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">{card.label}</p>
                    <div className="h-7 w-7 rounded-lg flex items-center justify-center"
                      style={{ background: `${card.color}18` }}>
                      <Icon className="h-4 w-4" style={{ color: card.color }} />
                    </div>
                  </div>
                  <div className="text-3xl font-bold font-mono" style={{ color: card.color }}>
                    <AnimatedCounter value={card.value} decimals={card.decimals} suffix={card.suffix} />
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">{card.sub}</p>
                </div>
              </motion.div>
            );
          })}
        </motion.div>
      ) : null}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.3, duration: 0.5 }}
          className="lg:col-span-2"
        >
          <Card className="glass-light border-white/5">
            <CardHeader>
              <CardTitle className="text-base">Risk Distribution Trend</CardTitle>
              <CardDescription className="text-xs">Approval vs rejection over the last 7 days</CardDescription>
            </CardHeader>
            <CardContent className="h-[280px]">
              {riskLoading ? (
                <Skeleton className="w-full h-full" />
              ) : riskDist && riskDist.length > 0 ? (
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={riskDist} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                    <defs>
                      <linearGradient id="colorGood" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#10b981" stopOpacity={0.3} />
                        <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                      </linearGradient>
                      <linearGradient id="colorBad" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#f43f5e" stopOpacity={0.3} />
                        <stop offset="95%" stopColor="#f43f5e" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(255,255,255,0.05)" />
                    <XAxis dataKey="date" tickFormatter={(val) => format(new Date(val), 'MMM d')}
                      stroke="rgba(255,255,255,0.2)" fontSize={11} tickLine={false} axisLine={false} dy={10} />
                    <YAxis stroke="rgba(255,255,255,0.2)" fontSize={11} tickLine={false} axisLine={false} dx={-10} />
                    <Tooltip
                      contentStyle={{ backgroundColor: 'rgba(15,23,42,0.95)', borderColor: 'rgba(255,255,255,0.1)', borderRadius: '10px', fontSize: '12px' }}
                      labelFormatter={(val) => format(new Date(val), 'MMM d, yyyy')}
                    />
                    <Area type="monotone" dataKey="good" name="Approved" stroke="#10b981" strokeWidth={2} fillOpacity={1} fill="url(#colorGood)" />
                    <Area type="monotone" dataKey="bad" name="Rejected" stroke="#f43f5e" strokeWidth={2} fillOpacity={1} fill="url(#colorBad)" />
                  </AreaChart>
                </ResponsiveContainer>
              ) : (
                <div className="w-full h-full flex items-center justify-center text-muted-foreground text-sm">No data available</div>
              )}
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.35, duration: 0.5 }}
        >
          <Card className="glass-light border-white/5">
            <CardHeader>
              <CardTitle className="text-base">Risk Breakdown</CardTitle>
              <CardDescription className="text-xs">Distribution across risk tiers</CardDescription>
            </CardHeader>
            <CardContent className="h-[280px] flex flex-col items-center justify-center">
              {statsLoading ? (
                <Skeleton className="w-full h-full" />
              ) : stats ? (
                <>
                  <ResponsiveContainer width="100%" height="180">
                    <PieChart>
                      <Pie data={pieData} cx="50%" cy="50%" innerRadius={50} outerRadius={70}
                        paddingAngle={4} dataKey="value" stroke="none" startAngle={90} endAngle={-270}>
                        {pieData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color}
                            style={{ filter: `drop-shadow(0 0 6px ${entry.color}60)` }} />
                        ))}
                      </Pie>
                      <Tooltip
                        contentStyle={{ backgroundColor: 'rgba(15,23,42,0.95)', borderColor: 'rgba(255,255,255,0.1)', borderRadius: '10px', fontSize: '12px' }}
                      />
                    </PieChart>
                  </ResponsiveContainer>
                  <div className="flex items-center gap-4 mt-2">
                    {pieData.map((d) => (
                      <div key={d.name} className="flex items-center gap-1.5 text-xs text-muted-foreground">
                        <div className="h-2 w-2 rounded-full" style={{ background: d.color }} />
                        <span>{d.name.split(" ")[0]}</span>
                        <span className="font-semibold" style={{ color: d.color }}>{d.value}</span>
                      </div>
                    ))}
                  </div>
                </>
              ) : null}
            </CardContent>
          </Card>
        </motion.div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.45, duration: 0.5 }}>
          <Card className="glass-light border-white/5">
            <CardHeader>
              <CardTitle className="text-base">Global Feature Importance</CardTitle>
              <CardDescription className="text-xs">Aggregate driver impact on model decisions</CardDescription>
            </CardHeader>
            <CardContent className="h-[300px]">
              {featureLoading ? (
                <Skeleton className="w-full h-full" />
              ) : featureImp && featureImp.length > 0 ? (
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={featureImp} layout="vertical" margin={{ top: 0, right: 20, left: 50, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" horizontal={false} vertical={true} stroke="rgba(255,255,255,0.05)" />
                    <XAxis type="number" stroke="rgba(255,255,255,0.2)" fontSize={11} tickLine={false} axisLine={false} />
                    <YAxis type="category" dataKey="feature" stroke="rgba(255,255,255,0.2)" fontSize={11} tickLine={false} axisLine={false} />
                    <Tooltip
                      cursor={{ fill: "rgba(255,255,255,0.04)" }}
                      contentStyle={{ backgroundColor: 'rgba(15,23,42,0.95)', borderColor: 'rgba(255,255,255,0.1)', borderRadius: '10px', fontSize: '12px' }}
                    />
                    <Bar dataKey="importance" barSize={16} radius={[0, 6, 6, 0]}>
                      {(featureImp || []).map((_: any, i: number) => (
                        <Cell key={i} fill={`hsl(${220 + i * 15}, 80%, ${60 - i * 3}%)`} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              ) : (
                <div className="w-full h-full flex items-center justify-center text-muted-foreground text-sm">No data available</div>
              )}
            </CardContent>
          </Card>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5, duration: 0.5 }}>
          <Card className="glass-light border-white/5">
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle className="text-base">Recent Assessments</CardTitle>
                <CardDescription className="text-xs">Latest model predictions</CardDescription>
              </div>
              <button
                className="text-xs font-medium text-primary hover:text-blue-300 transition-colors"
                onClick={() => setLocation("/predictions")}
              >
                View All →
              </button>
            </CardHeader>
            <CardContent className="space-y-2 p-4 pt-0">
              {recentLoading ? (
                <div className="space-y-2">
                  {[...Array(5)].map((_, i) => <Skeleton key={i} className="h-14 w-full rounded-lg" />)}
                </div>
              ) : recent?.predictions && recent.predictions.length > 0 ? (
                recent.predictions.map((p, idx) => (
                  <motion.div
                    key={p.id}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: idx * 0.05 + 0.5 }}
                    className="flex items-center justify-between p-3 rounded-lg cursor-pointer transition-all hover:bg-white/5 group"
                    style={{ border: "1px solid rgba(255,255,255,0.05)" }}
                    onClick={() => setLocation(`/predictions/${p.id}`)}
                  >
                    <div className="space-y-0.5">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-mono text-muted-foreground">#{p.id}</span>
                        <Badge
                          className="text-[10px] px-1.5 py-0 font-semibold"
                          style={{
                            background: p.creditworthy ? "rgba(16,185,129,0.15)" : "rgba(244,63,94,0.15)",
                            color: p.creditworthy ? "#10b981" : "#f43f5e",
                            border: `1px solid ${p.creditworthy ? "#10b981" : "#f43f5e"}30`,
                          }}
                        >
                          {p.creditworthy ? "APPROVED" : "REJECTED"}
                        </Badge>
                      </div>
                      <div className="text-[10px] text-muted-foreground">
                        {format(new Date(p.createdAt), "MMM d, HH:mm")} · {p.modelUsed?.replace("_", " ")}
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-xl font-bold font-mono" style={{
                        color: p.creditScore >= 70 ? "#10b981" : p.creditScore >= 50 ? "#f59e0b" : "#f43f5e"
                      }}>
                        {p.creditScore}
                      </div>
                      <div className="text-[10px] text-muted-foreground">score</div>
                    </div>
                  </motion.div>
                ))
              ) : (
                <div className="py-8 text-center text-muted-foreground text-sm">No recent predictions found.</div>
              )}
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
