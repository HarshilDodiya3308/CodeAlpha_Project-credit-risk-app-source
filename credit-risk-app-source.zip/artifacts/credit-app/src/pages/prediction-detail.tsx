import { useGetPredictionById } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";
import { useLocation } from "wouter";
import { format } from "date-fns";
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis, Cell } from "recharts";

export default function PredictionDetail({ params }: { params: { id: string } }) {
  const [, setLocation] = useLocation();
  const id = parseInt(params.id, 10);
  const { data, isLoading, error } = useGetPredictionById(id);

  if (error) {
    return (
      <div className="p-6 flex flex-col items-center justify-center min-h-[400px]">
        <h2 className="text-2xl font-bold mb-2">Assessment not found</h2>
        <Button onClick={() => setLocation("/predictions")} variant="outline">Back to History</Button>
      </div>
    );
  }

  const shapData = data?.shapValues ? [...data.shapValues].sort((a, b) => Math.abs(b.impact) - Math.abs(a.impact)) : [];

  return (
    <div className="p-6 max-w-[1200px] mx-auto space-y-6">
      <div className="flex items-center gap-4 mb-2">
        <Button variant="ghost" size="icon" onClick={() => setLocation("/predictions")}>
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Assessment #{id}</h1>
          <p className="text-muted-foreground">
            {isLoading ? "Loading..." : format(new Date(data!.createdAt), "MMMM d, yyyy 'at' HH:mm")}
          </p>
        </div>
      </div>

      {isLoading ? (
        <div className="space-y-6">
          <Skeleton className="h-40 w-full" />
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Skeleton className="h-64 w-full" />
            <Skeleton className="h-64 w-full" />
          </div>
        </div>
      ) : data ? (
        <>
          <Card className={data.creditworthy ? "border-primary/50 bg-primary/5" : "border-destructive/50 bg-destructive/5"}>
            <CardContent className="p-6 md:p-8 flex flex-col md:flex-row items-center justify-between gap-6">
              <div className="space-y-2 text-center md:text-left">
                <div className="text-sm font-medium text-muted-foreground uppercase tracking-wider">Final Verdict</div>
                <div className="text-4xl font-bold tracking-tight">
                  {data.creditworthy ? "APPROVED" : "REJECTED"}
                </div>
                <div className="flex items-center justify-center md:justify-start gap-2 pt-2">
                  <Badge variant="outline" className="bg-background">Model: {data.modelUsed}</Badge>
                  <Badge variant={
                    data.riskLevel === 'low' ? 'default' : 
                    data.riskLevel === 'medium' ? 'secondary' : 'destructive'
                  }>
                    {data.riskLevel.toUpperCase()} RISK
                  </Badge>
                </div>
              </div>

              <div className="flex items-center gap-6">
                <div className="text-center">
                  <div className="text-sm text-muted-foreground mb-1">Credit Score</div>
                  <div className="text-5xl font-bold font-mono">{data.creditScore}</div>
                </div>
                <div className="h-16 w-px bg-border hidden md:block"></div>
                <div className="text-center">
                  <div className="text-sm text-muted-foreground mb-1">Probability</div>
                  <div className="text-3xl font-semibold">{(data.probability * 100).toFixed(1)}%</div>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <Card className="lg:col-span-1">
              <CardHeader>
                <CardTitle>Input Parameters</CardTitle>
                <CardDescription>Data used for this prediction</CardDescription>
              </CardHeader>
              <CardContent>
                <dl className="space-y-4 text-sm">
                  <div className="flex justify-between border-b border-border pb-2">
                    <dt className="text-muted-foreground">Age</dt>
                    <dd className="font-medium">{data.inputData.age}</dd>
                  </div>
                  <div className="flex justify-between border-b border-border pb-2">
                    <dt className="text-muted-foreground">Income</dt>
                    <dd className="font-medium">${data.inputData.income.toLocaleString()}</dd>
                  </div>
                  <div className="flex justify-between border-b border-border pb-2">
                    <dt className="text-muted-foreground">Employment Length</dt>
                    <dd className="font-medium">{data.inputData.employmentLength} years</dd>
                  </div>
                  <div className="flex justify-between border-b border-border pb-2">
                    <dt className="text-muted-foreground">Credit History</dt>
                    <dd className="font-medium">{data.inputData.creditHistory} months</dd>
                  </div>
                  <div className="flex justify-between border-b border-border pb-2">
                    <dt className="text-muted-foreground">Existing Debt</dt>
                    <dd className="font-medium">${data.inputData.existingDebt.toLocaleString()}</dd>
                  </div>
                  <div className="flex justify-between border-b border-border pb-2">
                    <dt className="text-muted-foreground">Loan Amount</dt>
                    <dd className="font-medium">${data.inputData.loanAmount.toLocaleString()}</dd>
                  </div>
                  <div className="flex justify-between">
                    <dt className="text-muted-foreground">Loan Purpose</dt>
                    <dd className="font-medium capitalize">{data.inputData.loanPurpose}</dd>
                  </div>
                </dl>
              </CardContent>
            </Card>

            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle>Decision Explicability (SHAP)</CardTitle>
                <CardDescription>Feature contributions to the final prediction</CardDescription>
              </CardHeader>
              <CardContent className="h-[400px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={shapData} layout="vertical" margin={{ top: 0, right: 30, left: 80, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" horizontal={true} vertical={false} stroke="hsl(var(--border))" />
                    <XAxis type="number" stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} />
                    <YAxis type="category" dataKey="feature" stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} />
                    <Tooltip 
                      cursor={{fill: 'hsl(var(--muted))', opacity: 0.4}}
                      contentStyle={{ backgroundColor: 'hsl(var(--card))', borderColor: 'hsl(var(--border))', borderRadius: '8px' }}
                      formatter={(val: number) => [val.toFixed(4), "Impact"]}
                    />
                    <Bar dataKey="impact" radius={[0, 4, 4, 0]} barSize={24}>
                      {shapData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.impact > 0 ? "hsl(var(--primary))" : "hsl(var(--destructive))"} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
        </>
      ) : null}
    </div>
  );
}
