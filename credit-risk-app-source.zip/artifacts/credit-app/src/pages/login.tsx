import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { useLocation, Link } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { useLogin } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ParticleBg } from "@/components/particle-bg";
import { motion } from "framer-motion";
import { ShieldCheck, Zap, TrendingUp } from "lucide-react";
import { toast } from "sonner";

const loginSchema = z.object({
  email: z.string().email("Invalid email address"),
  password: z.string().min(1, "Password is required"),
});

type LoginForm = z.infer<typeof loginSchema>;

export default function Login() {
  const [, setLocation] = useLocation();
  const { setAuth } = useAuth();
  const loginMutation = useLogin();

  const form = useForm<LoginForm>({
    resolver: zodResolver(loginSchema),
    defaultValues: { email: "", password: "" },
  });

  const onSubmit = (data: LoginForm) => {
    loginMutation.mutate(
      { data },
      {
        onSuccess: (res) => {
          setAuth(res.token, res.user);
          toast.success("Access granted");
          setLocation("/dashboard");
        },
        onError: (err: any) => {
          toast.error(err?.message || "Authentication failed");
        },
      }
    );
  };

  return (
    <div className="min-h-screen w-full flex items-center justify-center overflow-hidden relative"
      style={{ background: "radial-gradient(ellipse at 60% 40%, #0d1b3e 0%, #030712 70%)" }}>
      <ParticleBg />

      <div className="absolute top-1/4 left-1/6 w-80 h-80 rounded-full opacity-20 blur-3xl animate-orb-1"
        style={{ background: "radial-gradient(circle, #3b82f6, transparent)" }} />
      <div className="absolute bottom-1/4 right-1/6 w-96 h-96 rounded-full opacity-15 blur-3xl animate-orb-2"
        style={{ background: "radial-gradient(circle, #8b5cf6, transparent)" }} />
      <div className="absolute top-1/2 left-1/2 w-64 h-64 rounded-full opacity-10 blur-3xl animate-orb-3"
        style={{ background: "radial-gradient(circle, #06b6d4, transparent)" }} />

      <div className="relative z-10 w-full max-w-md px-4">
        <motion.div
          initial={{ opacity: 0, y: -30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: "easeOut" }}
          className="flex flex-col items-center text-center mb-8"
        >
          <div className="relative mb-4">
            <div className="h-16 w-16 rounded-2xl flex items-center justify-center animate-pulse-glow"
              style={{ background: "linear-gradient(135deg, #3b82f6, #8b5cf6)" }}>
              <ShieldCheck className="h-8 w-8 text-white" />
            </div>
            <div className="absolute -inset-1 rounded-2xl blur-md opacity-40"
              style={{ background: "linear-gradient(135deg, #3b82f6, #8b5cf6)" }} />
          </div>
          <h1 className="text-3xl font-bold tracking-tight gradient-text mb-1 font-mono">CREDIT_RISK_OS</h1>
          <p className="text-sm text-muted-foreground">AI-powered precision risk assessment</p>
          <div className="flex gap-4 mt-3">
            {[
              { icon: Zap, label: "4 ML Models" },
              { icon: TrendingUp, label: "SHAP Explainability" },
              { icon: ShieldCheck, label: "Real-time Scoring" },
            ].map(({ icon: Icon, label }) => (
              <div key={label} className="flex items-center gap-1 text-xs text-muted-foreground">
                <Icon className="h-3 w-3 text-primary" />
                <span>{label}</span>
              </div>
            ))}
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 30, scale: 0.97 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          transition={{ duration: 0.6, delay: 0.15, ease: "easeOut" }}
          className="glass rounded-2xl p-8 shadow-2xl"
          style={{ boxShadow: "0 0 60px rgba(59,130,246,0.12), 0 25px 50px rgba(0,0,0,0.5)" }}
        >
          <div className="mb-6">
            <h2 className="text-xl font-bold">Authentication</h2>
            <p className="text-sm text-muted-foreground mt-1">Enter your credentials to access the terminal</p>
          </div>

          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
            <div className="space-y-2">
              <Label htmlFor="email" className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Email</Label>
              <Input
                id="email"
                type="email"
                placeholder="agent@replit.com"
                className="bg-white/5 border-white/10 focus:border-primary/60 focus:bg-white/8 transition-all h-11"
                {...form.register("email")}
              />
              {form.formState.errors.email && (
                <p className="text-xs text-destructive">{form.formState.errors.email.message}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="password" className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Password</Label>
              <Input
                id="password"
                type="password"
                placeholder="••••••••"
                className="bg-white/5 border-white/10 focus:border-primary/60 transition-all h-11"
                {...form.register("password")}
              />
              {form.formState.errors.password && (
                <p className="text-xs text-destructive">{form.formState.errors.password.message}</p>
              )}
            </div>

            <Button
              type="submit"
              className="w-full h-11 font-semibold text-sm relative overflow-hidden"
              disabled={loginMutation.isPending}
              style={{ background: loginMutation.isPending ? undefined : "linear-gradient(135deg, #3b82f6, #8b5cf6)" }}
            >
              {loginMutation.isPending ? (
                <span className="flex items-center gap-2">
                  <span className="h-4 w-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  Authenticating...
                </span>
              ) : "Initialize Session"}
            </Button>
          </form>

          <div className="mt-6 text-center text-sm text-muted-foreground border-t border-white/5 pt-5">
            Unregistered agent?{" "}
            <Link href="/register">
              <span className="text-primary hover:text-blue-300 font-medium cursor-pointer transition-colors">Request Access</span>
            </Link>
          </div>
        </motion.div>

        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="text-center text-xs text-muted-foreground mt-6"
        >
          Secured with JWT • ML-powered • SHAP explainability
        </motion.p>
      </div>
    </div>
  );
}
