import { useState } from "react";
import { useGetPredictions } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { ChevronLeft, ChevronRight, History } from "lucide-react";
import { useLocation } from "wouter";
import { format } from "date-fns";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";

function RiskBadge({ level }: { level: string }) {
  const styles: Record<string, { bg: string; color: string }> = {
    low: { bg: "rgba(16,185,129,0.12)", color: "#10b981" },
    medium: { bg: "rgba(245,158,11,0.12)", color: "#f59e0b" },
    high: { bg: "rgba(244,63,94,0.12)", color: "#f43f5e" },
  };
  const s = styles[level] || styles.medium;
  return (
    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold font-mono uppercase"
      style={{ background: s.bg, color: s.color, border: `1px solid ${s.color}30` }}>
      <span className="h-1.5 w-1.5 rounded-full" style={{ background: s.color }} />
      {level}
    </span>
  );
}

function ScoreMini({ score }: { score: number }) {
  const color = score >= 70 ? "#10b981" : score >= 50 ? "#f59e0b" : "#f43f5e";
  const pct = Math.min(100, Math.max(0, score));
  return (
    <div className="flex items-center gap-2">
      <div className="h-1.5 w-16 rounded-full overflow-hidden" style={{ background: "rgba(255,255,255,0.07)" }}>
        <div className="h-full rounded-full" style={{ width: `${pct}%`, background: color }} />
      </div>
      <span className="text-sm font-bold font-mono" style={{ color }}>{score}</span>
    </div>
  );
}

export default function Predictions() {
  const [, setLocation] = useLocation();
  const [page, setPage] = useState(1);
  const limit = 15;
  const { data, isLoading } = useGetPredictions({ page, limit });
  const totalPages = data?.total ? Math.ceil(data.total / limit) : 1;

  return (
    <div className="p-6 max-w-[1600px] mx-auto h-full flex flex-col">
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4"
      >
        <div>
          <h1 className="text-3xl font-bold tracking-tight gradient-text">Assessment History</h1>
          <p className="text-muted-foreground text-sm mt-1">Audit log of all model predictions.</p>
        </div>
        {data && (
          <div className="text-xs text-muted-foreground flex items-center gap-2">
            <History className="h-3.5 w-3.5" />
            {data.total} total assessments
          </div>
        )}
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="flex-1 flex flex-col min-h-0"
      >
        <div className="glass-light rounded-xl border border-white/5 flex-1 flex flex-col min-h-0 overflow-hidden">
          <div className="overflow-auto flex-1">
            <table className="w-full">
              <thead>
                <tr style={{ borderBottom: "1px solid rgba(255,255,255,0.06)", background: "rgba(255,255,255,0.02)" }}>
                  {["ID", "Date", "Score", "Risk Level", "Model", "Verdict"].map((h, i) => (
                    <th key={h} className={`px-5 py-3.5 text-left text-[10px] font-semibold uppercase tracking-widest text-muted-foreground ${i === 5 ? "text-right" : ""}`}>
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {isLoading ? (
                  [...Array(limit)].map((_, i) => (
                    <tr key={i} style={{ borderBottom: "1px solid rgba(255,255,255,0.04)" }}>
                      {[...Array(6)].map((_, j) => (
                        <td key={j} className="px-5 py-3.5">
                          <Skeleton className="h-4 w-full max-w-[100px]" />
                        </td>
                      ))}
                    </tr>
                  ))
                ) : data?.predictions && data.predictions.length > 0 ? (
                  data.predictions.map((p, idx) => (
                    <motion.tr
                      key={p.id}
                      initial={{ opacity: 0, x: -5 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: idx * 0.025 }}
                      className="group cursor-pointer transition-all"
                      style={{ borderBottom: "1px solid rgba(255,255,255,0.04)" }}
                      onClick={() => setLocation(`/predictions/${p.id}`)}
                      onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.background = "rgba(255,255,255,0.03)"; }}
                      onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.background = "transparent"; }}
                    >
                      <td className="px-5 py-3.5">
                        <span className="text-xs font-mono text-muted-foreground">#{p.id}</span>
                      </td>
                      <td className="px-5 py-3.5 text-sm text-muted-foreground">
                        {format(new Date(p.createdAt), "MMM d, yyyy")}
                        <span className="text-muted-foreground/50 ml-1">{format(new Date(p.createdAt), "HH:mm")}</span>
                      </td>
                      <td className="px-5 py-3.5">
                        <ScoreMini score={p.creditScore} />
                      </td>
                      <td className="px-5 py-3.5">
                        <RiskBadge level={p.riskLevel} />
                      </td>
                      <td className="px-5 py-3.5 text-xs text-muted-foreground font-mono">
                        {p.modelUsed?.replace(/_/g, " ")}
                      </td>
                      <td className="px-5 py-3.5 text-right">
                        <span className="inline-flex items-center px-2.5 py-1 rounded-full text-[11px] font-semibold uppercase"
                          style={{
                            background: p.creditworthy ? "rgba(16,185,129,0.12)" : "rgba(244,63,94,0.12)",
                            color: p.creditworthy ? "#10b981" : "#f43f5e",
                            border: `1px solid ${p.creditworthy ? "rgba(16,185,129,0.25)" : "rgba(244,63,94,0.25)"}`,
                          }}>
                          {p.creditworthy ? "✓ APPROVED" : "✕ REJECTED"}
                        </span>
                      </td>
                    </motion.tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={6} className="h-32 text-center text-muted-foreground text-sm">
                      No predictions found.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          <div className="px-5 py-3 flex items-center justify-between"
            style={{ borderTop: "1px solid rgba(255,255,255,0.06)", background: "rgba(255,255,255,0.02)" }}>
            <div className="text-xs text-muted-foreground">
              Page <span className="font-semibold text-foreground">{page}</span> of {totalPages}
              {data && <span className="ml-2 text-muted-foreground/50">({data.total} total)</span>}
            </div>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" className="h-8 text-xs border-white/10 bg-white/5 hover:bg-white/10"
                onClick={() => setPage(p => Math.max(1, p - 1))}
                disabled={page === 1 || isLoading}>
                <ChevronLeft className="h-3.5 w-3.5 mr-1" /> Prev
              </Button>
              <Button variant="outline" size="sm" className="h-8 text-xs border-white/10 bg-white/5 hover:bg-white/10"
                onClick={() => setPage(p => p + 1)}
                disabled={!data || data.predictions.length < limit || isLoading}>
                Next <ChevronRight className="h-3.5 w-3.5 ml-1" />
              </Button>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
