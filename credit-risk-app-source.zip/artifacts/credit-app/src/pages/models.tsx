import { useGetModelMetrics, useGetActiveModel, useSetActiveModel } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis, Legend, RadarChart, Radar, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Cell } from "recharts";
import { toast } from "sonner";
import { useQueryClient } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { Cpu, CheckCircle2, Zap, BarChart3 } from "lucide-react";

const MODEL_META: Record<string, { color: string; desc: string; icon: string }> = {
  logistic_regression: { color: "#60a5fa", desc: "Fast, interpretable linear classifier", icon: "📊" },
  decision_tree:       { color: "#a78bfa", desc: "Explainable single-tree decision rules", icon: "🌿" },
  random_forest:       { color: "#34d399", desc: "Ensemble for robust generalization", icon: "🌲" },
  xgboost:             { color: "#f59e0b", desc: "Gradient boosting, highest accuracy", icon: "⚡" },
};

const METRIC_COLORS = ["#60a5fa","#a78bfa","#34d399","#f59e0b","#f43f5e"];

export default function Models() {
  const queryClient = useQueryClient();
  const { data: metrics, isLoading: metricsLoading } = useGetModelMetrics();
  const { data: activeModel, isLoading: activeLoading } = useGetActiveModel();
  const setActiveModel = useSetActiveModel();

  const handleSetActive = (modelName: string) => {
    setActiveModel.mutate(
      { data: { modelName } },
      {
        onSuccess: () => {
          toast.success(`${modelName.replace(/_/g, " ")} is now active`);
          queryClient.invalidateQueries({ queryKey: ["/api/models/active"] });
        },
        onError: (err: any) => toast.error(err?.message || "Failed to switch model"),
      }
    );
  };

  const chartData = metrics
    ? metrics.map((m) => ({
        name: m.modelName.replace(/_/g, " ").replace(/\b\w/g, (l: string) => l.toUpperCase()),
        rawName: m.modelName,
        Accuracy: Number((m.accuracy * 100).toFixed(1)),
        Precision: Number((m.precision * 100).toFixed(1)),
        Recall: Number((m.recall * 100).toFixed(1)),
        "F1 Score": Number((m.f1Score * 100).toFixed(1)),
        "ROC AUC": Number((m.rocAuc * 100).toFixed(1)),
      }))
    : [];

  const radarData = metrics
    ? [
        { metric: "Accuracy", ...Object.fromEntries(metrics.map((m) => [m.modelName, Number((m.accuracy * 100).toFixed(1))])) },
        { metric: "Precision", ...Object.fromEntries(metrics.map((m) => [m.modelName, Number((m.precision * 100).toFixed(1))])) },
        { metric: "Recall", ...Object.fromEntries(metrics.map((m) => [m.modelName, Number((m.recall * 100).toFixed(1))])) },
        { metric: "F1", ...Object.fromEntries(metrics.map((m) => [m.modelName, Number((m.f1Score * 100).toFixed(1))])) },
        { metric: "ROC AUC", ...Object.fromEntries(metrics.map((m) => [m.modelName, Number((m.rocAuc * 100).toFixed(1))])) },
      ]
    : [];

  return (
    <div className="p-6 max-w-[1600px] mx-auto space-y-6">
      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="text-3xl font-bold tracking-tight gradient-text">ML Model Registry</h1>
        <p className="text-muted-foreground text-sm mt-1">Compare, evaluate, and deploy machine learning models.</p>
      </motion.div>

      {metricsLoading || activeLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {[...Array(4)].map((_, i) => <Skeleton key={i} className="h-40 rounded-xl" />)}
        </div>
      ) : metrics ? (
        <motion.div
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4"
          initial="hidden"
          animate="visible"
          variants={{ hidden: {}, visible: { transition: { staggerChildren: 0.07 } } }}
        >
          {metrics.map((m) => {
            const meta = MODEL_META[m.modelName] || { color: "#60a5fa", desc: "", icon: "🤖" };
            const isActive = activeModel?.modelName === m.modelName;
            return (
              <motion.div
                key={m.modelName}
                variants={{ hidden: { opacity: 0, y: 20 }, visible: { opacity: 1, y: 0, transition: { duration: 0.4 } } }}
              >
                <div
                  className="relative rounded-xl p-5 h-full flex flex-col card-hover cursor-default"
                  style={{
                    background: isActive
                      ? `linear-gradient(135deg, ${meta.color}18, ${meta.color}06)`
                      : "rgba(15,23,42,0.7)",
                    border: isActive ? `1px solid ${meta.color}40` : "1px solid rgba(255,255,255,0.07)",
                    boxShadow: isActive ? `0 0 32px ${meta.color}20` : "none",
                  }}
                >
                  {isActive && (
                    <div className="absolute top-3 right-3">
                      <div className="flex items-center gap-1 text-[10px] px-2 py-0.5 rounded-full font-semibold"
                        style={{ background: `${meta.color}20`, color: meta.color, border: `1px solid ${meta.color}30` }}>
                        <span className="h-1.5 w-1.5 rounded-full animate-pulse" style={{ background: meta.color }} />
                        ACTIVE
                      </div>
                    </div>
                  )}
                  <div className="text-2xl mb-2">{meta.icon}</div>
                  <h3 className="font-bold text-sm capitalize mb-1">{m.modelName.replace(/_/g, " ")}</h3>
                  <p className="text-xs text-muted-foreground mb-4 flex-1">{meta.desc}</p>

                  <div className="grid grid-cols-2 gap-2 mb-4">
                    {[
                      { label: "Accuracy", val: m.accuracy },
                      { label: "F1 Score", val: m.f1Score },
                      { label: "Precision", val: m.precision },
                      { label: "ROC AUC", val: m.rocAuc },
                    ].map(({ label, val }) => (
                      <div key={label} className="rounded-lg p-2 text-center"
                        style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.05)" }}>
                        <div className="text-sm font-bold font-mono" style={{ color: meta.color }}>
                          {(val * 100).toFixed(1)}%
                        </div>
                        <div className="text-[9px] text-muted-foreground uppercase tracking-wide mt-0.5">{label}</div>
                      </div>
                    ))}
                  </div>

                  <div className="mb-3">
                    <div className="flex justify-between text-[10px] text-muted-foreground mb-1">
                      <span>Performance</span>
                      <span style={{ color: meta.color }}>{(m.rocAuc * 100).toFixed(1)}% AUC</span>
                    </div>
                    <div className="h-1.5 rounded-full overflow-hidden" style={{ background: "rgba(255,255,255,0.07)" }}>
                      <motion.div
                        className="h-full rounded-full"
                        initial={{ width: 0 }}
                        animate={{ width: `${m.rocAuc * 100}%` }}
                        transition={{ duration: 1, delay: 0.3, ease: "easeOut" }}
                        style={{ background: meta.color }}
                      />
                    </div>
                  </div>

                  <Button
                    size="sm"
                    className="w-full text-xs h-8"
                    disabled={isActive || setActiveModel.isPending}
                    onClick={() => handleSetActive(m.modelName)}
                    style={isActive ? undefined : {
                      background: `linear-gradient(135deg, ${meta.color}90, ${meta.color}60)`,
                      border: `1px solid ${meta.color}40`,
                    }}
                  >
                    {isActive ? (
                      <span className="flex items-center gap-1.5">
                        <CheckCircle2 className="h-3 w-3" /> Deployed
                      </span>
                    ) : (
                      <span className="flex items-center gap-1.5">
                        <Zap className="h-3 w-3" /> Deploy
                      </span>
                    )}
                  </Button>
                </div>
              </motion.div>
            );
          })}
        </motion.div>
      ) : null}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}>
          <Card className="glass-light border-white/5">
            <CardHeader>
              <div className="flex items-center gap-2">
                <BarChart3 className="h-4 w-4 text-primary" />
                <CardTitle className="text-base">Performance Metrics</CardTitle>
              </div>
              <CardDescription className="text-xs">Evaluation scores across all algorithms</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[300px]">
                {metricsLoading ? (
                  <Skeleton className="w-full h-full" />
                ) : chartData.length > 0 ? (
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={chartData} margin={{ top: 10, right: 10, left: 0, bottom: 5 }}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(255,255,255,0.05)" />
                      <XAxis dataKey="name" stroke="rgba(255,255,255,0.2)" fontSize={11} tickLine={false} axisLine={false} />
                      <YAxis domain={[60, 100]} stroke="rgba(255,255,255,0.2)" fontSize={11} tickLine={false} axisLine={false} tickFormatter={(v) => `${v}%`} />
                      <Tooltip
                        contentStyle={{ backgroundColor: 'rgba(15,23,42,0.95)', borderColor: 'rgba(255,255,255,0.1)', borderRadius: '10px', fontSize: '12px' }}
                        cursor={{ fill: "rgba(255,255,255,0.03)" }}
                      />
                      <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '12px' }} />
                      {METRIC_COLORS.map((color, i) => (
                        <Bar key={i} dataKey={["Accuracy","Precision","Recall","F1 Score","ROC AUC"][i]}
                          fill={color} radius={[3, 3, 0, 0]} barSize={10} />
                      ))}
                    </BarChart>
                  </ResponsiveContainer>
                ) : null}
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.45 }}>
          <Card className="glass-light border-white/5">
            <CardHeader>
              <div className="flex items-center gap-2">
                <Cpu className="h-4 w-4 text-primary" />
                <CardTitle className="text-base">Radar Comparison</CardTitle>
              </div>
              <CardDescription className="text-xs">Multi-dimensional model performance overview</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[300px]">
                {metricsLoading ? (
                  <Skeleton className="w-full h-full" />
                ) : radarData.length > 0 && metrics ? (
                  <ResponsiveContainer width="100%" height="100%">
                    <RadarChart data={radarData}>
                      <PolarGrid stroke="rgba(255,255,255,0.1)" />
                      <PolarAngleAxis dataKey="metric" stroke="rgba(255,255,255,0.4)" fontSize={11} />
                      <PolarRadiusAxis angle={90} domain={[60, 90]} stroke="rgba(255,255,255,0.1)" fontSize={9} />
                      {metrics.map((m) => {
                        const meta = MODEL_META[m.modelName] || { color: "#60a5fa" };
                        return (
                          <Radar
                            key={m.modelName}
                            name={m.modelName.replace(/_/g, " ")}
                            dataKey={m.modelName}
                            stroke={meta.color}
                            fill={meta.color}
                            fillOpacity={0.08}
                            strokeWidth={1.5}
                          />
                        );
                      })}
                      <Legend wrapperStyle={{ fontSize: '11px' }} />
                      <Tooltip
                        contentStyle={{ backgroundColor: 'rgba(15,23,42,0.95)', borderColor: 'rgba(255,255,255,0.1)', borderRadius: '10px', fontSize: '12px' }}
                      />
                    </RadarChart>
                  </ResponsiveContainer>
                ) : null}
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
