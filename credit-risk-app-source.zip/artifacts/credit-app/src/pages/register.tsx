import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { useLocation, Link } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { useRegister } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ParticleBg } from "@/components/particle-bg";
import { motion } from "framer-motion";
import { ShieldCheck } from "lucide-react";
import { toast } from "sonner";

const registerSchema = z.object({
  username: z.string().min(3, "Username must be at least 3 characters"),
  email: z.string().email("Invalid email address"),
  password: z.string().min(6, "Password must be at least 6 characters"),
});

type RegisterForm = z.infer<typeof registerSchema>;

export default function Register() {
  const [, setLocation] = useLocation();
  const { setAuth } = useAuth();
  const registerMutation = useRegister();

  const form = useForm<RegisterForm>({
    resolver: zodResolver(registerSchema),
    defaultValues: { username: "", email: "", password: "" },
  });

  const onSubmit = (data: RegisterForm) => {
    registerMutation.mutate(
      { data },
      {
        onSuccess: (res) => {
          setAuth(res.token, res.user);
          toast.success("Account created — welcome aboard");
          setLocation("/dashboard");
        },
        onError: (err: any) => {
          toast.error(err?.message || "Registration failed");
        },
      }
    );
  };

  return (
    <div className="min-h-screen w-full flex items-center justify-center overflow-hidden relative"
      style={{ background: "radial-gradient(ellipse at 40% 60%, #0d1b3e 0%, #030712 70%)" }}>
      <ParticleBg />

      <div className="absolute top-1/3 right-1/4 w-80 h-80 rounded-full opacity-20 blur-3xl animate-orb-2"
        style={{ background: "radial-gradient(circle, #8b5cf6, transparent)" }} />
      <div className="absolute bottom-1/3 left-1/4 w-72 h-72 rounded-full opacity-15 blur-3xl animate-orb-1"
        style={{ background: "radial-gradient(circle, #06b6d4, transparent)" }} />

      <div className="relative z-10 w-full max-w-md px-4">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="flex flex-col items-center text-center mb-8"
        >
          <div className="relative mb-4">
            <div className="h-16 w-16 rounded-2xl flex items-center justify-center"
              style={{ background: "linear-gradient(135deg, #8b5cf6, #3b82f6)" }}>
              <ShieldCheck className="h-8 w-8 text-white" />
            </div>
            <div className="absolute -inset-1 rounded-2xl blur-md opacity-40"
              style={{ background: "linear-gradient(135deg, #8b5cf6, #3b82f6)" }} />
          </div>
          <h1 className="text-3xl font-bold tracking-tight gradient-text mb-1 font-mono">CREDIT_RISK_OS</h1>
          <p className="text-sm text-muted-foreground">Authorized personnel only</p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 30, scale: 0.97 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="glass rounded-2xl p-8 shadow-2xl"
          style={{ boxShadow: "0 0 60px rgba(139,92,246,0.12), 0 25px 50px rgba(0,0,0,0.5)" }}
        >
          <div className="mb-6">
            <h2 className="text-xl font-bold">Request Access</h2>
            <p className="text-sm text-muted-foreground mt-1">Register a new analyst account</p>
          </div>

          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
            <div className="space-y-2">
              <Label htmlFor="username" className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Username</Label>
              <Input id="username" placeholder="jdoe_analyst"
                className="bg-white/5 border-white/10 focus:border-primary/60 transition-all h-11"
                {...form.register("username")} />
              {form.formState.errors.username && <p className="text-xs text-destructive">{form.formState.errors.username.message}</p>}
            </div>
            <div className="space-y-2">
              <Label htmlFor="email" className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Email</Label>
              <Input id="email" type="email" placeholder="agent@replit.com"
                className="bg-white/5 border-white/10 focus:border-primary/60 transition-all h-11"
                {...form.register("email")} />
              {form.formState.errors.email && <p className="text-xs text-destructive">{form.formState.errors.email.message}</p>}
            </div>
            <div className="space-y-2">
              <Label htmlFor="password" className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Password</Label>
              <Input id="password" type="password" placeholder="••••••••"
                className="bg-white/5 border-white/10 focus:border-primary/60 transition-all h-11"
                {...form.register("password")} />
              {form.formState.errors.password && <p className="text-xs text-destructive">{form.formState.errors.password.message}</p>}
            </div>
            <Button type="submit" className="w-full h-11 font-semibold text-sm"
              disabled={registerMutation.isPending}
              style={{ background: registerMutation.isPending ? undefined : "linear-gradient(135deg, #8b5cf6, #3b82f6)" }}>
              {registerMutation.isPending ? (
                <span className="flex items-center gap-2">
                  <span className="h-4 w-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  Creating Account...
                </span>
              ) : "Create Account"}
            </Button>
          </form>

          <div className="mt-6 text-center text-sm text-muted-foreground border-t border-white/5 pt-5">
            Already registered?{" "}
            <Link href="/login">
              <span className="text-primary hover:text-blue-300 font-medium cursor-pointer transition-colors">Authenticate</span>
            </Link>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
