# Deployment Guide

## Replit (Current — Dev)
Both services run via Replit workflows:
- **Frontend**: `artifacts/credit-app: web` — Vite dev server
- **Backend**: `artifacts/api-server: API Server` — Python Flask on port 8080

## Docker

### Backend
```dockerfile
FROM python:3.11-slim
WORKDIR /app
COPY python-service/requirements.txt .
RUN pip install -r requirements.txt
COPY python-service/ .
ENV PORT=8080
CMD ["python", "app.py"]
```

### Frontend
```dockerfile
FROM node:20-alpine AS builder
WORKDIR /app
COPY . .
RUN npm install -g pnpm && pnpm install
RUN pnpm --filter @workspace/credit-app run build

FROM nginx:alpine
COPY --from=builder /app/artifacts/credit-app/dist/public /usr/share/nginx/html
```

### docker-compose.yml
```yaml
version: "3.9"
services:
  api:
    build:
      context: .
      dockerfile: Dockerfile.api
    ports:
      - "8080:8080"
    environment:
      SESSION_SECRET: your-secret-key
  web:
    build:
      context: .
      dockerfile: Dockerfile.web
    ports:
      - "80:80"
    depends_on:
      - api
```

## Render

1. Create a new **Web Service**
2. Set runtime: **Python 3**
3. Build command: `pip install -r python-service/requirements.txt`
4. Start command: `python python-service/app.py`
5. Set env var `SESSION_SECRET` to a strong secret
6. Deploy frontend as a **Static Site** from `artifacts/credit-app/dist/public`

## Railway

1. Create project → Add service → GitHub repo
2. Configure environment: Python
3. Set `START_COMMAND=python python-service/app.py`
4. Set `SESSION_SECRET` env var
5. Add second service for the frontend (Static)

## AWS (Elastic Beanstalk)

1. Create EB application → Python platform
2. Upload a zip of `python-service/` + requirements.txt
3. Set `SESSION_SECRET` in EB environment properties
4. Use S3 + CloudFront for the frontend static build

## Production Checklist

- [ ] Replace SQLite with PostgreSQL (`psycopg2`, update `get_db()`)
- [ ] Use a production WSGI server (`gunicorn app:app`)
- [ ] Set `SESSION_SECRET` to a cryptographically random value
- [ ] Enable HTTPS everywhere
- [ ] Serve frontend via CDN (CloudFront, Vercel, Netlify)
- [ ] Set up database backups
- [ ] Add rate limiting to `/api/predictions`
