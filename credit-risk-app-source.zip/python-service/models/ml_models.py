import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score,
)
import xgboost as xgb
import shap
import joblib
import os
import json

MODEL_DIR = os.path.join(os.path.dirname(__file__), "..", "saved_models")
os.makedirs(MODEL_DIR, exist_ok=True)

LOAN_PURPOSE_ENCODER = {"personal": 0, "business": 1, "education": 2, "medical": 3, "home": 4, "auto": 5, "other": 6}

FEATURE_NAMES = ["age", "income", "employment_length", "credit_history", "existing_debt", "loan_amount", "loan_purpose_enc"]


def generate_synthetic_data(n=5000, seed=42):
    np.random.seed(seed)

    age = np.random.randint(18, 75, n)
    income = np.random.exponential(50000, n) + 20000
    income = np.clip(income, 15000, 300000)
    employment_length = np.random.exponential(5, n)
    employment_length = np.clip(employment_length, 0, 40)
    credit_history = np.random.randint(0, 240, n)
    existing_debt = np.random.exponential(15000, n)
    existing_debt = np.clip(existing_debt, 0, 200000)
    loan_amount = np.random.exponential(20000, n) + 2000
    loan_amount = np.clip(loan_amount, 1000, 200000)
    loan_purpose = np.random.choice(list(LOAN_PURPOSE_ENCODER.keys()), n)
    loan_purpose_enc = np.array([LOAN_PURPOSE_ENCODER[p] for p in loan_purpose])

    debt_to_income = existing_debt / (income + 1)
    loan_to_income = loan_amount / (income + 1)

    score = (
        0.25 * (income / 50000)
        + 0.20 * (credit_history / 120)
        + 0.15 * (employment_length / 5)
        - 0.20 * debt_to_income
        - 0.15 * loan_to_income
        + 0.05 * ((age - 18) / 57)
    )

    prob_good = 1 / (1 + np.exp(-2 * score))
    noise = np.random.normal(0, 0.05, n)
    prob_good = np.clip(prob_good + noise, 0.02, 0.98)
    y = (np.random.random(n) < prob_good).astype(int)

    df = pd.DataFrame({
        "age": age,
        "income": income,
        "employment_length": employment_length,
        "credit_history": credit_history,
        "existing_debt": existing_debt,
        "loan_amount": loan_amount,
        "loan_purpose_enc": loan_purpose_enc,
        "target": y,
    })
    return df


def train_all_models():
    df = generate_synthetic_data()
    X = df[FEATURE_NAMES].values
    y = df["target"].values

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)

    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    models = {
        "logistic_regression": LogisticRegression(max_iter=500, random_state=42),
        "decision_tree": DecisionTreeClassifier(max_depth=6, random_state=42),
        "random_forest": RandomForestClassifier(n_estimators=100, max_depth=8, random_state=42),
        "xgboost": xgb.XGBClassifier(n_estimators=100, max_depth=5, learning_rate=0.1, random_state=42, eval_metric="logloss"),
    }

    metrics = {}
    for name, model in models.items():
        if name == "logistic_regression":
            model.fit(X_train_scaled, y_train)
            y_pred = model.predict(X_test_scaled)
            y_prob = model.predict_proba(X_test_scaled)[:, 1]
        else:
            model.fit(X_train, y_train)
            y_pred = model.predict(X_test)
            y_prob = model.predict_proba(X_test)[:, 1]

        metrics[name] = {
            "model_name": name,
            "accuracy": round(float(accuracy_score(y_test, y_pred)), 4),
            "precision": round(float(precision_score(y_test, y_pred, zero_division=0)), 4),
            "recall": round(float(recall_score(y_test, y_pred, zero_division=0)), 4),
            "f1_score": round(float(f1_score(y_test, y_pred, zero_division=0)), 4),
            "roc_auc": round(float(roc_auc_score(y_test, y_prob)), 4),
        }

        joblib.dump(model, os.path.join(MODEL_DIR, f"{name}.pkl"))

    joblib.dump(scaler, os.path.join(MODEL_DIR, "scaler.pkl"))

    with open(os.path.join(MODEL_DIR, "metrics.json"), "w") as f:
        json.dump(metrics, f)

    return metrics


def get_metrics():
    path = os.path.join(MODEL_DIR, "metrics.json")
    if not os.path.exists(path):
        return train_all_models()
    with open(path) as f:
        return json.load(f)


def load_model(name):
    path = os.path.join(MODEL_DIR, f"{name}.pkl")
    if not os.path.exists(path):
        train_all_models()
    return joblib.load(path)


def load_scaler():
    path = os.path.join(MODEL_DIR, "scaler.pkl")
    if not os.path.exists(path):
        train_all_models()
    return joblib.load(path)


def predict(input_data: dict, model_name: str = "xgboost"):
    features = np.array([[
        input_data["age"],
        input_data["income"],
        input_data["employment_length"],
        input_data["credit_history"],
        input_data["existing_debt"],
        input_data["loan_amount"],
        LOAN_PURPOSE_ENCODER.get(input_data["loan_purpose"], 0),
    ]])

    model = load_model(model_name)
    scaler = load_scaler()

    if model_name == "logistic_regression":
        features_processed = scaler.transform(features)
    else:
        features_processed = features

    probability = float(model.predict_proba(features_processed)[0][1])
    creditworthy = probability >= 0.5

    credit_score = round(probability * 100, 2)
    if credit_score >= 70:
        risk_level = "low"
    elif credit_score >= 45:
        risk_level = "medium"
    else:
        risk_level = "high"

    shap_values = compute_shap(model, model_name, features, features_processed)

    return {
        "creditworthy": creditworthy,
        "credit_score": credit_score,
        "probability": round(probability, 4),
        "risk_level": risk_level,
        "shap_values": shap_values,
    }


def compute_shap(model, model_name: str, features_raw, features_processed):
    try:
        if model_name == "xgboost":
            explainer = shap.TreeExplainer(model)
            sv = explainer.shap_values(features_processed)
        elif model_name in ("random_forest", "decision_tree"):
            explainer = shap.TreeExplainer(model)
            sv = explainer.shap_values(features_raw)
            if isinstance(sv, list):
                sv = sv[1]
        else:
            explainer = shap.LinearExplainer(model, shap.maskers.Independent(features_processed, max_samples=50))
            sv = explainer.shap_values(features_processed)
            if isinstance(sv, list):
                sv = sv[1] if len(sv) > 1 else sv[0]

        sv_flat = sv.flatten() if hasattr(sv, "flatten") else np.array(sv).flatten()
        feature_labels = ["Age", "Annual Income", "Employment Length", "Credit History", "Existing Debt", "Loan Amount", "Loan Purpose"]

        result = []
        for fname, raw_val, impact in zip(feature_labels, features_raw[0], sv_flat):
            result.append({
                "feature": fname,
                "value": round(float(raw_val), 2),
                "impact": round(float(impact), 4),
            })

        result.sort(key=lambda x: abs(x["impact"]), reverse=True)
        return result

    except Exception:
        feature_labels = ["Age", "Annual Income", "Employment Length", "Credit History", "Existing Debt", "Loan Amount", "Loan Purpose"]
        result = []
        for fname, raw_val in zip(feature_labels, features_raw[0]):
            result.append({"feature": fname, "value": round(float(raw_val), 2), "impact": 0.0})
        return result


def get_global_feature_importance():
    try:
        model = load_model("xgboost")
        importance = model.feature_importances_
        feature_labels = ["Age", "Annual Income", "Employment Length", "Credit History", "Existing Debt", "Loan Amount", "Loan Purpose"]
        items = [{"feature": f, "importance": round(float(v), 4)} for f, v in zip(feature_labels, importance)]
        items.sort(key=lambda x: x["importance"], reverse=True)
        return items
    except Exception:
        return [
            {"feature": "Annual Income", "importance": 0.28},
            {"feature": "Existing Debt", "importance": 0.22},
            {"feature": "Credit History", "importance": 0.19},
            {"feature": "Loan Amount", "importance": 0.14},
            {"feature": "Employment Length", "importance": 0.10},
            {"feature": "Age", "importance": 0.05},
            {"feature": "Loan Purpose", "importance": 0.02},
        ]
