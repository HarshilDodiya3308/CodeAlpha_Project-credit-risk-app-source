import sqlite3
import os
import json
from datetime import datetime

DB_PATH = os.path.join(os.path.dirname(__file__), "..", "credit_scoring.db")


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_db()
    c = conn.cursor()

    c.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            role TEXT NOT NULL DEFAULT 'user',
            created_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS predictions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            age INTEGER NOT NULL,
            income REAL NOT NULL,
            employment_length REAL NOT NULL,
            credit_history INTEGER NOT NULL,
            existing_debt REAL NOT NULL,
            loan_amount REAL NOT NULL,
            loan_purpose TEXT NOT NULL,
            model_name TEXT NOT NULL,
            creditworthy INTEGER NOT NULL,
            credit_score REAL NOT NULL,
            probability REAL NOT NULL,
            risk_level TEXT NOT NULL,
            shap_values TEXT NOT NULL,
            created_at TEXT NOT NULL,
            FOREIGN KEY (user_id) REFERENCES users(id)
        );

        CREATE TABLE IF NOT EXISTS model_settings (
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL
        );
    """)

    c.execute(
        "INSERT OR IGNORE INTO model_settings (key, value) VALUES ('active_model', 'xgboost')"
    )

    conn.commit()
    conn.close()


def seed_demo_data():
    """Seed sample predictions for dashboard demonstration."""
    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT COUNT(*) as cnt FROM predictions")
    count = c.fetchone()["cnt"]

    if count == 0:
        import random
        random.seed(42)
        base_date = datetime(2026, 5, 25)
        purposes = ["personal", "business", "education", "medical", "home", "auto"]
        models = ["logistic_regression", "decision_tree", "random_forest", "xgboost"]
        for i in range(50):
            day_offset = random.randint(0, 13)
            created = datetime(2026, 6, 1 + day_offset, random.randint(8, 20), random.randint(0, 59))
            creditworthy = random.choice([True, True, False])
            score = random.uniform(65, 92) if creditworthy else random.uniform(20, 48)
            prob = score / 100.0
            risk = "low" if score >= 70 else ("medium" if score >= 50 else "high")
            shap = json.dumps([
                {"feature": "income", "value": random.uniform(30000, 120000), "impact": random.uniform(-0.3, 0.3)},
                {"feature": "credit_history", "value": random.randint(12, 120), "impact": random.uniform(-0.2, 0.25)},
                {"feature": "existing_debt", "value": random.uniform(0, 30000), "impact": random.uniform(-0.25, 0.1)},
                {"feature": "loan_amount", "value": random.uniform(5000, 50000), "impact": random.uniform(-0.15, 0.15)},
                {"feature": "employment_length", "value": random.uniform(0, 15), "impact": random.uniform(-0.1, 0.2)},
                {"feature": "age", "value": random.randint(22, 65), "impact": random.uniform(-0.08, 0.12)},
            ])
            c.execute(
                """INSERT INTO predictions
                   (user_id, age, income, employment_length, credit_history, existing_debt,
                    loan_amount, loan_purpose, model_name, creditworthy, credit_score,
                    probability, risk_level, shap_values, created_at)
                   VALUES (NULL, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    random.randint(22, 65),
                    random.uniform(30000, 150000),
                    random.uniform(0, 15),
                    random.randint(12, 120),
                    random.uniform(0, 50000),
                    random.uniform(5000, 80000),
                    random.choice(purposes),
                    random.choice(models),
                    1 if creditworthy else 0,
                    round(score, 2),
                    round(prob, 4),
                    risk,
                    shap,
                    created.isoformat(),
                ),
            )
        conn.commit()
    conn.close()
