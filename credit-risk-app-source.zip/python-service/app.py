import os
import sys

sys.path.insert(0, os.path.dirname(__file__))

from flask import Flask, jsonify
from flask_cors import CORS
from flask_jwt_extended import JWTManager

from models.database import init_db, seed_demo_data
from routes.auth import auth_bp
from routes.predictions import predictions_bp
from routes.dashboard import dashboard_bp
from routes.models_routes import models_bp

app = Flask(__name__)

app.config["JWT_SECRET_KEY"] = os.environ.get("SESSION_SECRET", "credit-scoring-dev-secret-2026")
app.config["JWT_ACCESS_TOKEN_EXPIRES"] = False

CORS(app, resources={r"/api/*": {"origins": "*"}}, supports_credentials=True)
jwt = JWTManager(app)

app.register_blueprint(auth_bp, url_prefix="/api/auth")
app.register_blueprint(predictions_bp, url_prefix="/api/predictions")
app.register_blueprint(dashboard_bp, url_prefix="/api/dashboard")
app.register_blueprint(models_bp, url_prefix="/api/models")


@app.route("/api/healthz")
def health():
    return jsonify({"status": "ok"})


@jwt.unauthorized_loader
def unauthorized_callback(error_string):
    return jsonify({"error": "Missing or invalid token"}), 401


@jwt.invalid_token_loader
def invalid_token_callback(error_string):
    return jsonify({"error": "Invalid token"}), 401


@jwt.expired_token_loader
def expired_token_callback(jwt_header, jwt_payload):
    return jsonify({"error": "Token has expired"}), 401


if __name__ == "__main__":
    print("Initializing database...", flush=True)
    init_db()
    print("Seeding demo data...", flush=True)
    seed_demo_data()
    print("Training ML models (first run may take ~30s)...", flush=True)

    from models.ml_models import get_metrics
    try:
        get_metrics()
        print("ML models ready.", flush=True)
    except Exception as e:
        print(f"Model training warning: {e}", flush=True)

    port = int(os.environ.get("PORT", 8080))
    print(f"Starting Flask on port {port}...", flush=True)
    app.run(host="0.0.0.0", port=port, debug=False)
