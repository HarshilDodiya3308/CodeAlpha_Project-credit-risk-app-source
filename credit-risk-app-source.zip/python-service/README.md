# AI-Powered Credit Risk Assessment — Python ML Service

## Overview
Flask REST API serving ML predictions for credit risk assessment.

## Models
- Logistic Regression
- Decision Tree
- Random Forest
- XGBoost (default)

## Setup
```bash
pip install -r requirements.txt
python app.py
```

## API Endpoints
- `GET  /api/healthz`
- `POST /api/auth/register`
- `POST /api/auth/login`
- `GET  /api/auth/me`
- `POST /api/predictions`
- `GET  /api/predictions`
- `GET  /api/predictions/:id`
- `GET  /api/dashboard/stats`
- `GET  /api/dashboard/risk-distribution`
- `GET  /api/dashboard/feature-importance`
- `GET  /api/dashboard/recent-predictions`
- `GET  /api/models/metrics`
- `GET  /api/models/active`
- `PATCH /api/models/active`
