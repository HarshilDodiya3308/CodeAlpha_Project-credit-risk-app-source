from flask import Blueprint, request, jsonify
from flask_jwt_extended import create_access_token, jwt_required, get_jwt_identity
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
import json
from models.database import get_db

auth_bp = Blueprint("auth", __name__)


@auth_bp.route("/register", methods=["POST"])
def register():
    data = request.get_json()
    if not data:
        return jsonify({"error": "No data provided"}), 400

    username = data.get("username", "").strip()
    email = data.get("email", "").strip().lower()
    password = data.get("password", "")

    if not username or not email or not password:
        return jsonify({"error": "username, email, and password are required"}), 400
    if len(username) < 3:
        return jsonify({"error": "Username must be at least 3 characters"}), 400
    if len(password) < 6:
        return jsonify({"error": "Password must be at least 6 characters"}), 400

    password_hash = generate_password_hash(password)
    conn = get_db()
    c = conn.cursor()
    try:
        c.execute(
            "INSERT INTO users (username, email, password_hash, role, created_at) VALUES (?, ?, ?, ?, ?)",
            (username, email, password_hash, "user", datetime.utcnow().isoformat()),
        )
        conn.commit()
        user_id = c.lastrowid
    except Exception as e:
        conn.close()
        return jsonify({"error": "Username or email already exists"}), 400

    conn.close()

    token = create_access_token(identity=json.dumps({"id": user_id, "username": username, "email": email, "role": "user"}))
    return jsonify({
        "token": token,
        "user": {"id": user_id, "username": username, "email": email, "role": "user"},
    }), 201


@auth_bp.route("/login", methods=["POST"])
def login():
    data = request.get_json()
    if not data:
        return jsonify({"error": "No data provided"}), 400

    email = data.get("email", "").strip().lower()
    password = data.get("password", "")

    if not email or not password:
        return jsonify({"error": "email and password are required"}), 400

    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT * FROM users WHERE email = ?", (email,))
    user = c.fetchone()
    conn.close()

    if not user or not check_password_hash(user["password_hash"], password):
        return jsonify({"error": "Invalid email or password"}), 401

    token = create_access_token(
        identity=json.dumps({"id": user["id"], "username": user["username"], "email": user["email"], "role": user["role"]})
    )
    return jsonify({
        "token": token,
        "user": {"id": user["id"], "username": user["username"], "email": user["email"], "role": user["role"]},
    })


@auth_bp.route("/me", methods=["GET"])
@jwt_required()
def get_me():
    identity = json.loads(get_jwt_identity())
    return jsonify(identity)
