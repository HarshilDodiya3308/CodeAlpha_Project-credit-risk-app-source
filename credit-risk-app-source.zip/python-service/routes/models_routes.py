from flask import Blueprint, request, jsonify
from models.ml_models import get_metrics, train_all_models
from models.database import get_db

models_bp = Blueprint("models", __name__)

VALID_MODELS = ["logistic_regression", "decision_tree", "random_forest", "xgboost"]


@models_bp.route("/metrics", methods=["GET"])
def get_model_metrics():
    metrics = get_metrics()
    result = [
        {
            "modelName": m["model_name"],
            "accuracy": m["accuracy"],
            "precision": m["precision"],
            "recall": m["recall"],
            "f1Score": m["f1_score"],
            "rocAuc": m["roc_auc"],
        }
        for m in metrics.values()
    ]
    return jsonify(result)


@models_bp.route("/active", methods=["GET"])
def get_active_model():
    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT value FROM model_settings WHERE key = 'active_model'")
    row = c.fetchone()
    conn.close()
    model_name = row["value"] if row else "xgboost"
    return jsonify({"modelName": model_name})


@models_bp.route("/active", methods=["PATCH"])
def set_active_model():
    data = request.get_json()
    if not data or "modelName" not in data:
        return jsonify({"error": "modelName is required"}), 400
    model_name = data["modelName"]
    if model_name not in VALID_MODELS:
        return jsonify({"error": f"Invalid model. Choose from: {VALID_MODELS}"}), 400

    conn = get_db()
    c = conn.cursor()
    c.execute("INSERT OR REPLACE INTO model_settings (key, value) VALUES ('active_model', ?)", (model_name,))
    conn.commit()
    conn.close()
    return jsonify({"modelName": model_name})
