from flask import Blueprint, jsonify
from datetime import datetime, timedelta
import json
from models.database import get_db
from models.ml_models import get_global_feature_importance, get_metrics

dashboard_bp = Blueprint("dashboard", __name__)


@dashboard_bp.route("/stats", methods=["GET"])
def get_stats():
    conn = get_db()
    c = conn.cursor()

    c.execute("SELECT COUNT(*) as cnt FROM predictions")
    total = c.fetchone()["cnt"]

    c.execute("SELECT COUNT(*) as cnt FROM predictions WHERE creditworthy = 1")
    approved = c.fetchone()["cnt"]

    c.execute("SELECT AVG(credit_score) as avg FROM predictions")
    avg_score = c.fetchone()["avg"] or 0.0

    c.execute("SELECT COUNT(*) as cnt FROM predictions WHERE risk_level = 'high'")
    high_risk = c.fetchone()["cnt"]
    c.execute("SELECT COUNT(*) as cnt FROM predictions WHERE risk_level = 'medium'")
    medium_risk = c.fetchone()["cnt"]
    c.execute("SELECT COUNT(*) as cnt FROM predictions WHERE risk_level = 'low'")
    low_risk = c.fetchone()["cnt"]

    today = datetime.utcnow().date().isoformat()
    c.execute("SELECT COUNT(*) as cnt FROM predictions WHERE created_at LIKE ?", (f"{today}%",))
    today_count = c.fetchone()["cnt"]

    conn.close()

    approval_rate = round((approved / total * 100), 2) if total > 0 else 0.0

    metrics = get_metrics()
    model_accuracies = {name: m["accuracy"] for name, m in metrics.items()}

    return jsonify({
        "totalPredictions": total,
        "approvalRate": approval_rate,
        "avgCreditScore": round(avg_score, 2),
        "highRiskCount": high_risk,
        "mediumRiskCount": medium_risk,
        "lowRiskCount": low_risk,
        "todayPredictions": today_count,
        "modelAccuracies": model_accuracies,
    })


@dashboard_bp.route("/risk-distribution", methods=["GET"])
def get_risk_distribution():
    conn = get_db()
    c = conn.cursor()

    result = []
    today = datetime.utcnow().date()
    for i in range(7, -1, -1):
        day = today - timedelta(days=i)
        day_str = day.isoformat()
        c.execute(
            "SELECT COUNT(*) as cnt FROM predictions WHERE creditworthy = 1 AND date(created_at) = ?",
            (day_str,),
        )
        good = c.fetchone()["cnt"]
        c.execute(
            "SELECT COUNT(*) as cnt FROM predictions WHERE creditworthy = 0 AND date(created_at) = ?",
            (day_str,),
        )
        bad = c.fetchone()["cnt"]
        result.append({"date": day.strftime("%b %d"), "good": good, "bad": bad})

    conn.close()
    return jsonify(result)


@dashboard_bp.route("/feature-importance", methods=["GET"])
def get_feature_importance():
    items = get_global_feature_importance()
    return jsonify(items)


@dashboard_bp.route("/recent-predictions", methods=["GET"])
def get_recent_predictions():
    conn = get_db()
    c = conn.cursor()
    c.execute("""
        SELECT p.id, p.creditworthy, p.credit_score, p.risk_level, p.model_name, p.created_at, u.username
        FROM predictions p
        LEFT JOIN users u ON p.user_id = u.id
        ORDER BY p.created_at DESC
        LIMIT 20
    """)
    rows = c.fetchall()
    conn.close()

    result = []
    for row in rows:
        result.append({
            "id": row["id"],
            "creditworthy": bool(row["creditworthy"]),
            "creditScore": row["credit_score"],
            "riskLevel": row["risk_level"],
            "modelUsed": row["model_name"],
            "createdAt": row["created_at"],
            "username": row["username"],
        })
    return jsonify(result)
