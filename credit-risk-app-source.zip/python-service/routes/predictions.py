from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity, verify_jwt_in_request
from datetime import datetime
import json
from models.database import get_db
from models.ml_models import predict

predictions_bp = Blueprint("predictions", __name__)


def get_current_user_id():
    try:
        verify_jwt_in_request(optional=True)
        identity = get_jwt_identity()
        if identity:
            return json.loads(identity)["id"]
    except Exception:
        pass
    return None


@predictions_bp.route("", methods=["POST"])
def create_prediction():
    data = request.get_json()
    if not data:
        return jsonify({"error": "No data provided"}), 400

    required = ["age", "income", "employmentLength", "creditHistory", "existingDebt", "loanAmount", "loanPurpose"]
    for field in required:
        if field not in data:
            return jsonify({"error": f"Missing field: {field}"}), 400

    model_name = data.get("modelName", "xgboost")
    valid_models = ["logistic_regression", "decision_tree", "random_forest", "xgboost"]
    if model_name not in valid_models:
        return jsonify({"error": f"Invalid model. Choose from: {valid_models}"}), 400

    input_data = {
        "age": int(data["age"]),
        "income": float(data["income"]),
        "employment_length": float(data["employmentLength"]),
        "credit_history": int(data["creditHistory"]),
        "existing_debt": float(data["existingDebt"]),
        "loan_amount": float(data["loanAmount"]),
        "loan_purpose": str(data["loanPurpose"]),
    }

    result = predict(input_data, model_name)
    user_id = get_current_user_id()

    conn = get_db()
    c = conn.cursor()
    c.execute(
        """INSERT INTO predictions
           (user_id, age, income, employment_length, credit_history, existing_debt,
            loan_amount, loan_purpose, model_name, creditworthy, credit_score,
            probability, risk_level, shap_values, created_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        (
            user_id,
            input_data["age"],
            input_data["income"],
            input_data["employment_length"],
            input_data["credit_history"],
            input_data["existing_debt"],
            input_data["loan_amount"],
            input_data["loan_purpose"],
            model_name,
            1 if result["creditworthy"] else 0,
            result["credit_score"],
            result["probability"],
            result["risk_level"],
            json.dumps(result["shap_values"]),
            datetime.utcnow().isoformat(),
        ),
    )
    conn.commit()
    pred_id = c.lastrowid
    conn.close()

    return jsonify(_format_prediction(
        pred_id, result["creditworthy"], result["credit_score"],
        result["probability"], result["risk_level"], model_name,
        result["shap_values"], data, datetime.utcnow().isoformat(), user_id
    ))


@predictions_bp.route("", methods=["GET"])
def get_predictions():
    page = int(request.args.get("page", 1))
    limit = int(request.args.get("limit", 10))
    offset = (page - 1) * limit

    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT COUNT(*) as cnt FROM predictions")
    total = c.fetchone()["cnt"]
    c.execute("SELECT * FROM predictions ORDER BY created_at DESC LIMIT ? OFFSET ?", (limit, offset))
    rows = c.fetchall()
    conn.close()

    predictions = [_row_to_result(r) for r in rows]
    return jsonify({"predictions": predictions, "total": total, "page": page, "limit": limit})


@predictions_bp.route("/<int:pred_id>", methods=["GET"])
def get_prediction_by_id(pred_id):
    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT * FROM predictions WHERE id = ?", (pred_id,))
    row = c.fetchone()
    conn.close()

    if not row:
        return jsonify({"error": "Prediction not found"}), 404

    return jsonify(_row_to_result(row))


def _format_prediction(pred_id, creditworthy, credit_score, probability, risk_level, model_name, shap_values, input_data, created_at, user_id):
    return {
        "id": pred_id,
        "creditworthy": creditworthy,
        "creditScore": credit_score,
        "probability": probability,
        "riskLevel": risk_level,
        "modelUsed": model_name,
        "shapValues": shap_values,
        "inputData": {
            "age": input_data.get("age"),
            "income": input_data.get("income"),
            "employmentLength": input_data.get("employmentLength"),
            "creditHistory": input_data.get("creditHistory"),
            "existingDebt": input_data.get("existingDebt"),
            "loanAmount": input_data.get("loanAmount"),
            "loanPurpose": input_data.get("loanPurpose"),
            "modelName": input_data.get("modelName", "xgboost"),
        },
        "createdAt": created_at,
        "userId": user_id,
    }


def _row_to_result(row):
    shap_values = json.loads(row["shap_values"]) if row["shap_values"] else []
    return {
        "id": row["id"],
        "creditworthy": bool(row["creditworthy"]),
        "creditScore": row["credit_score"],
        "probability": row["probability"],
        "riskLevel": row["risk_level"],
        "modelUsed": row["model_name"],
        "shapValues": shap_values,
        "inputData": {
            "age": row["age"],
            "income": row["income"],
            "employmentLength": row["employment_length"],
            "creditHistory": row["credit_history"],
            "existingDebt": row["existing_debt"],
            "loanAmount": row["loan_amount"],
            "loanPurpose": row["loan_purpose"],
            "modelName": row["model_name"],
        },
        "createdAt": row["created_at"],
        "userId": row["user_id"],
    }
