# API Documentation — AI Credit Risk Assessment

Base URL: `/api`
Auth: `Authorization: Bearer <jwt_token>` (where required)

---

## Authentication

### POST /api/auth/register
Register a new user.

**Request:**
```json
{
  "username": "string (min 3 chars)",
  "email": "string",
  "password": "string (min 6 chars)"
}
```

**Response 201:**
```json
{
  "token": "jwt_token_string",
  "user": { "id": 1, "username": "john", "email": "john@example.com", "role": "user" }
}
```

---

### POST /api/auth/login
Login with existing credentials.

**Request:**
```json
{ "email": "string", "password": "string" }
```

**Response 200:**
```json
{
  "token": "jwt_token_string",
  "user": { "id": 1, "username": "john", "email": "john@example.com", "role": "user" }
}
```

---

### GET /api/auth/me
Get current authenticated user. Requires JWT.

**Response 200:**
```json
{ "id": 1, "username": "john", "email": "john@example.com", "role": "user" }
```

---

## Credit Predictions

### POST /api/predictions
Submit a credit assessment. Works with or without auth.

**Request:**
```json
{
  "age": 35,
  "income": 75000,
  "employmentLength": 5.5,
  "creditHistory": 84,
  "existingDebt": 12000,
  "loanAmount": 25000,
  "loanPurpose": "home",
  "modelName": "xgboost"
}
```

**modelName options:** `logistic_regression`, `decision_tree`, `random_forest`, `xgboost`

**Response 200:**
```json
{
  "id": 42,
  "creditworthy": true,
  "creditScore": 78.4,
  "probability": 0.784,
  "riskLevel": "low",
  "modelUsed": "xgboost",
  "shapValues": [
    { "feature": "Annual Income", "value": 75000.0, "impact": 0.1823 },
    { "feature": "Existing Debt", "value": 12000.0, "impact": -0.0912 }
  ],
  "inputData": { ... },
  "createdAt": "2026-06-09T10:00:00",
  "userId": null
}
```

---

### GET /api/predictions?page=1&limit=10
Get prediction history (paginated).

**Response 200:**
```json
{
  "predictions": [ ... ],
  "total": 55,
  "page": 1,
  "limit": 10
}
```

---

### GET /api/predictions/:id
Get a single prediction by ID.

---

## Dashboard

### GET /api/dashboard/stats
Overview statistics.

**Response 200:**
```json
{
  "totalPredictions": 55,
  "approvalRate": 62.0,
  "avgCreditScore": 68.4,
  "highRiskCount": 19,
  "mediumRiskCount": 7,
  "lowRiskCount": 29,
  "todayPredictions": 3,
  "modelAccuracies": {
    "logistic_regression": 0.756,
    "decision_tree": 0.738,
    "random_forest": 0.751,
    "xgboost": 0.782
  }
}
```

---

### GET /api/dashboard/risk-distribution
7-day good vs bad credit trend.

**Response 200:** `[{ "date": "Jun 03", "good": 4, "bad": 2 }, ...]`

---

### GET /api/dashboard/feature-importance
Global feature importance from XGBoost.

**Response 200:** `[{ "feature": "Annual Income", "importance": 0.28 }, ...]`

---

### GET /api/dashboard/recent-predictions
Last 20 predictions across all users.

---

## ML Models

### GET /api/models/metrics
All 4 model evaluation metrics.

**Response 200:**
```json
[
  {
    "modelName": "xgboost",
    "accuracy": 0.782,
    "precision": 0.791,
    "recall": 0.863,
    "f1Score": 0.825,
    "rocAuc": 0.841
  }
]
```

---

### GET /api/models/active
Get the currently active model name.

**Response 200:** `{ "modelName": "xgboost" }`

---

### PATCH /api/models/active
Switch to a different model.

**Request:** `{ "modelName": "random_forest" }`
**Response 200:** `{ "modelName": "random_forest" }`

---

## Health

### GET /api/healthz
**Response 200:** `{ "status": "ok" }`
