# Database Schema — Credit Risk Assessment (SQLite)

## users
| Column         | Type    | Notes                         |
|----------------|---------|-------------------------------|
| id             | INTEGER | Primary key, autoincrement    |
| username       | TEXT    | Unique, not null              |
| email          | TEXT    | Unique, not null              |
| password_hash  | TEXT    | Werkzeug PBKDF2 hash          |
| role           | TEXT    | 'user' or 'admin'             |
| created_at     | TEXT    | ISO 8601 datetime             |

## predictions
| Column             | Type    | Notes                                    |
|--------------------|---------|------------------------------------------|
| id                 | INTEGER | Primary key, autoincrement               |
| user_id            | INTEGER | FK to users.id (nullable — anon allowed) |
| age                | INTEGER |                                          |
| income             | REAL    |                                          |
| employment_length  | REAL    | Years                                    |
| credit_history     | INTEGER | Months of credit history                 |
| existing_debt      | REAL    |                                          |
| loan_amount        | REAL    |                                          |
| loan_purpose       | TEXT    | personal/business/education/medical/home/auto/other |
| model_name         | TEXT    | logistic_regression/decision_tree/random_forest/xgboost |
| creditworthy       | INTEGER | 1 = Good, 0 = Bad                        |
| credit_score       | REAL    | 0–100 (probability × 100)                |
| probability        | REAL    | Raw model probability 0–1                |
| risk_level         | TEXT    | low/medium/high                          |
| shap_values        | TEXT    | JSON array of {feature, value, impact}   |
| created_at         | TEXT    | ISO 8601 datetime                        |

## model_settings
| Column | Type | Notes                        |
|--------|------|------------------------------|
| key    | TEXT | Primary key (e.g. 'active_model') |
| value  | TEXT | Current setting value        |
