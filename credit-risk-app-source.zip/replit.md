# AI-Powered Credit Risk Assessment System

A production-ready credit scoring system that predicts loan applicant creditworthiness using machine learning — featuring 4 ML models, SHAP explainability, JWT auth, and a real-time risk dashboard.

## Run & Operate

- `python python-service/app.py` — run the Python Flask ML API (port 8080)
- `pnpm --filter @workspace/credit-app run dev` — run the React frontend
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec

## Stack

- **Frontend**: React + Vite, TanStack Query, Recharts, Tailwind CSS, shadcn/ui, Zustand, Wouter
- **Backend**: Python Flask, JWT auth, Flask-CORS
- **ML**: scikit-learn, XGBoost, SHAP values
- **DB**: SQLite (via `python-service/credit_scoring.db`)
- **API Contracts**: OpenAPI 3.1 → Orval codegen (React Query hooks + Zod schemas)

## Where things live

- `python-service/app.py` — Flask entry point (routes, JWT, CORS)
- `python-service/models/ml_models.py` — Model training, inference, SHAP computation
- `python-service/models/database.py` — SQLite schema, seeding
- `python-service/routes/` — Auth, predictions, dashboard, model routes
- `python-service/saved_models/` — Serialized .pkl model files + metrics.json
- `lib/api-spec/openapi.yaml` — API contract (source of truth)
- `artifacts/credit-app/src/` — React frontend pages and components

## Architecture decisions

- Python Flask serves the ML backend; the Node.js api-server artifact was repurposed to run Flask on port 8080 via the shared proxy at `/api`
- Models are trained on synthetic data (5,000 rows) at first startup using a realistic credit scoring formula; saved to disk as .pkl files
- SHAP values are computed per-prediction using TreeExplainer (XGBoost/RF/DT) or LinearExplainer (LR) for post-hoc explainability
- JWT tokens are stored in localStorage and attached via `setAuthTokenGetter` from the generated custom-fetch client
- SQLite is used for simplicity in dev; swap `get_db()` in database.py for psycopg2 in production

## Product

- **Login / Register** — JWT-based user auth with role support (user/admin)
- **Credit Assessment** — 7-input form that runs predictions against 4 ML models and shows credit score, risk level, and SHAP impact chart
- **Dashboard** — Approval rate, average score, risk distribution charts, feature importance, recent predictions
- **Prediction History** — Paginated table of all past assessments with detail drill-down
- **Model Registry** — Compare Logistic Regression, Decision Tree, Random Forest, XGBoost metrics; switch active model

## Gotchas

- First startup trains all 4 ML models (~10-30s) and seeds 50 demo predictions — subsequent starts are instant
- The artifact.toml for api-server runs `python /home/runner/workspace/python-service/app.py` — absolute path required because the workflow CWD is the artifact folder
- SHAP's TreeExplainer returns a list for binary classifiers (sklearn RF/DT) — always take `sv[1]` for class 1

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._
