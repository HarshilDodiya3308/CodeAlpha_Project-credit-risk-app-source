# Local Setup Guide — AI Credit Risk Assessment System

## Prerequisites

| Tool | Version | Install |
|------|---------|---------|
| Node.js | 18+ | https://nodejs.org |
| pnpm | 9+ | `npm install -g pnpm` |
| Python | 3.10+ | https://python.org |

---

## 1. Install Python dependencies

```bash
cd python-service
pip install -r requirements.txt
```

> First install takes ~2 minutes (scikit-learn, XGBoost, SHAP are large packages).

---

## 2. Install Node.js dependencies

```bash
# From the project root
pnpm install
```

---

## 3. Set environment variables

Create a `.env` file in `python-service/`:

```env
SESSION_SECRET=your-super-secret-jwt-key-here
PORT=8080
```

Or export them in your shell:

```bash
export SESSION_SECRET="dev-secret-key"
export PORT=8080
```

---

## 4. Run the Python ML backend

```bash
cd python-service
python app.py
```

First run trains all 4 ML models (~10-30 seconds) and seeds 50 demo predictions.  
Subsequent runs start in under 1 second.

**API available at:** `http://localhost:8080`

---

## 5. Run the React frontend

Open a **second terminal**:

```bash
# From the project root
pnpm --filter @workspace/credit-app run dev
```

**App available at:** `http://localhost:5173`

---

## 6. Configure the API base URL (important!)

The frontend uses a shared proxy in Replit. Locally you need to point it at Flask directly.

Open `artifacts/credit-app/vite.config.ts` and add a proxy:

```ts
export default defineConfig({
  // ...existing config...
  server: {
    proxy: {
      '/api': {
        target: 'http://localhost:8080',
        changeOrigin: true,
      }
    }
  }
})
```

---

## 7. Open in browser

Navigate to `http://localhost:5173` and click **Request Access** to register.

---

## Project Structure

```
credit-risk-app/
├── python-service/          # Flask ML backend
│   ├── app.py               # Entry point (routes, JWT, CORS)
│   ├── requirements.txt     # Python packages
│   ├── models/
│   │   ├── ml_models.py     # 4 ML models + SHAP
│   │   └── database.py      # SQLite schema + seeding
│   └── routes/
│       ├── auth.py          # Register / Login / Me
│       ├── predictions.py   # Credit assessments
│       ├── dashboard.py     # Stats + charts
│       └── models_routes.py # Model registry
│
├── artifacts/credit-app/    # React frontend
│   └── src/
│       ├── pages/           # login, dashboard, predict, predictions, models
│       ├── components/      # layout, score-gauge, particle-bg, animated-counter
│       └── hooks/           # use-auth (Zustand)
│
├── lib/
│   ├── api-spec/            # OpenAPI 3.1 contract
│   ├── api-client-react/    # Generated React Query hooks
│   └── api-zod/             # Generated Zod schemas
│
└── pnpm-workspace.yaml      # Monorepo config
```

---

## VS Code recommended extensions

- **Python** (ms-python.python)
- **ESLint** (dbaeumer.vscode-eslint)
- **Tailwind CSS IntelliSense** (bradlc.vscode-tailwindcss)
- **Prettier** (esbenp.prettier-vscode)

---

## Default demo credentials

After first startup, register any email/password via the UI — no default users are seeded.

---

## Regenerate API client (after changing openapi.yaml)

```bash
pnpm --filter @workspace/api-spec run codegen
```

---

## Common issues

| Problem | Fix |
|---------|-----|
| `ModuleNotFoundError: shap` | Run `pip install shap` in python-service/ |
| Port 8080 already in use | `export PORT=8081` and update the Vite proxy target |
| `zustand` not found | Run `pnpm install` from the project root |
| Models not loading | Delete `python-service/saved_models/` folder and restart |
